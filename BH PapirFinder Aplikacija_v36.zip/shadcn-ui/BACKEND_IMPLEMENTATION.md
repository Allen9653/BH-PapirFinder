# BH PapirFinder - Backend Implementation Guide

## Overview

This document provides a complete guide for implementing the backend infrastructure for BH PapirFinder using Firebase Functions, Google Sheets API, and PayPal integration.

## Prerequisites

1. **Firebase Project Setup**
   - Create a Firebase project at https://console.firebase.google.com
   - Enable Firebase Authentication
   - Enable Cloud Firestore or Realtime Database
   - Enable Cloud Functions

2. **Google Sheets API Setup**
   - Enable Google Sheets API in Google Cloud Console
   - Create a Service Account
   - Download Service Account JSON credentials
   - Share the Google Sheet with the Service Account email

3. **PayPal API Setup**
   - Create PayPal Developer account
   - Get Client ID and Secret Key
   - Configure webhook URL

## Firebase Functions Implementation

### 1. Install Dependencies

```bash
cd functions
npm install firebase-functions firebase-admin googleapis @paypal/checkout-server-sdk
```

### 2. Environment Variables

```bash
firebase functions:config:set \
  google.sheets.id="1CVy0yh93F7IvMsH8D2OQlwSMxhwJMJTJHP_oHMxDjMw" \
  google.service_account="$(cat service-account.json)" \
  paypal.client_id="YOUR_PAYPAL_CLIENT_ID" \
  paypal.secret="YOUR_PAYPAL_SECRET" \
  paypal.mode="sandbox"
```

### 3. Google Sheets Integration Function

```typescript
// functions/src/google-sheets.ts
import { google } from 'googleapis';
import * as functions from 'firebase-functions';

const sheets = google.sheets('v4');

async function getGoogleSheetsClient() {
  const serviceAccount = JSON.parse(
    functions.config().google.service_account
  );
  
  const auth = new google.auth.GoogleAuth({
    credentials: serviceAccount,
    scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
  });
  
  return await auth.getClient();
}

export async function searchMunicipality(municipalityName: string) {
  const auth = await getGoogleSheetsClient();
  const spreadsheetId = functions.config().google.sheets.id;
  
  const response = await sheets.spreadsheets.values.get({
    auth: auth as any,
    spreadsheetId,
    range: 'Sheet1!A:F', // Adjust range based on your sheet structure
  });
  
  const rows = response.data.values || [];
  const results = rows.filter(row => 
    row[0]?.toLowerCase().includes(municipalityName.toLowerCase())
  );
  
  if (results.length === 0) return null;
  
  return {
    name: results[0][0],
    urls: results[0][1]?.split(',') || [],
    descriptions: results[0][2]?.split(',') || [],
    forms: results[0][3]?.split(',') || [],
    komentar: results[0][4] || '',
    category: results[0][5] || '',
  };
}
```

### 4. Search API Endpoint with Caching

```typescript
// functions/src/index.ts
import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import { searchMunicipality } from './google-sheets';

admin.initializeApp();
const db = admin.firestore();

export const searchMunicipalityAPI = functions.https.onCall(async (data, context) => {
  const { municipalityName } = data;
  
  if (!municipalityName) {
    throw new functions.https.HttpsError('invalid-argument', 'Municipality name is required');
  }
  
  // Check cache first
  const cacheKey = municipalityName.toLowerCase();
  const cacheRef = db.collection('municipality_cache').doc(cacheKey);
  const cacheDoc = await cacheRef.get();
  
  if (cacheDoc.exists) {
    const cached = cacheDoc.data();
    const expiresAt = cached?.expiresAt?.toDate();
    
    if (expiresAt && expiresAt > new Date()) {
      console.log('Returning cached data for:', municipalityName);
      return cached.data;
    }
  }
  
  // Query Google Sheets
  const result = await searchMunicipality(municipalityName);
  
  if (result) {
    // Cache for 24 hours
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);
    
    await cacheRef.set({
      data: result,
      cachedAt: admin.firestore.FieldValue.serverTimestamp(),
      expiresAt: admin.firestore.Timestamp.fromDate(expiresAt),
    });
  }
  
  return result;
});
```

### 5. PayPal Webhook Handler

```typescript
// functions/src/paypal.ts
import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as crypto from 'crypto';

export const paypalWebhook = functions.https.onRequest(async (req, res) => {
  // Verify webhook signature
  const webhookId = req.headers['paypal-webhook-id'] as string;
  const transmissionId = req.headers['paypal-transmission-id'] as string;
  const transmissionTime = req.headers['paypal-transmission-time'] as string;
  const transmissionSig = req.headers['paypal-transmission-sig'] as string;
  
  const webhookSecret = functions.config().paypal.secret;
  const expectedSig = `${transmissionId}|${transmissionTime}|${webhookId}|${crc32(JSON.stringify(req.body))}`;
  
  const hmac = crypto.createHmac('sha256', webhookSecret);
  hmac.update(expectedSig);
  const computedSig = hmac.digest('base64');
  
  if (computedSig !== transmissionSig) {
    console.error('Invalid webhook signature');
    res.status(401).send('Unauthorized');
    return;
  }
  
  // Process webhook event
  const event = req.body;
  
  if (event.event_type === 'PAYMENT.CAPTURE.COMPLETED') {
    const payerEmail = event.resource.payer.email_address;
    const amount = event.resource.amount.value;
    
    // Generate login code
    const loginCode = generateLoginCode();
    
    // Store user data
    await admin.firestore().collection('users').add({
      email: payerEmail,
      loginCode,
      amount: parseFloat(amount),
      paidAt: admin.firestore.FieldValue.serverTimestamp(),
      expiresAt: calculateExpiryDate(amount),
    });
    
    // Send email with login code
    await sendLoginCodeEmail(payerEmail, loginCode);
    
    console.log('Payment processed:', event.resource.id);
  }
  
  res.status(200).send('OK');
});

function generateLoginCode(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

function calculateExpiryDate(amount: number): admin.firestore.Timestamp {
  const now = new Date();
  let days = 0;
  
  if (amount === 10) days = 5;
  else if (amount === 50) days = 30;
  else if (amount === 60) days = 365;
  
  now.setDate(now.getDate() + days);
  return admin.firestore.Timestamp.fromDate(now);
}

async function sendLoginCodeEmail(email: string, loginCode: string) {
  // Implement email sending using SendGrid, Mailgun, or Firebase Extensions
  console.log(`Sending login code ${loginCode} to ${email}`);
}

function crc32(str: string): number {
  // CRC32 implementation
  let crc = 0 ^ (-1);
  for (let i = 0; i < str.length; i++) {
    crc = (crc >>> 8) ^ crc32Table[(crc ^ str.charCodeAt(i)) & 0xFF];
  }
  return (crc ^ (-1)) >>> 0;
}

const crc32Table = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i;
  for (let j = 0; j < 8; j++) {
    c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
  }
  crc32Table[i] = c;
}
```

### 6. Admin Functions

```typescript
// functions/src/admin.ts
export const clearCache = functions.https.onCall(async (data, context) => {
  // Verify admin authentication
  if (!context.auth || context.auth.token.email !== 'alenjusufovic@yahoo.com') {
    throw new functions.https.HttpsError('permission-denied', 'Admin access required');
  }
  
  const batch = db.batch();
  const cacheSnapshot = await db.collection('municipality_cache').get();
  
  cacheSnapshot.docs.forEach(doc => {
    batch.delete(doc.ref);
  });
  
  await batch.commit();
  
  return { success: true, cleared: cacheSnapshot.size };
});

export const syncGoogleSheets = functions.https.onCall(async (data, context) => {
  // Verify admin authentication
  if (!context.auth || context.auth.token.email !== 'alenjusufovic@yahoo.com') {
    throw new functions.https.HttpsError('permission-denied', 'Admin access required');
  }
  
  // Clear cache and force re-fetch
  await clearCache(data, context);
  
  return { success: true, message: 'Cache cleared, next search will fetch fresh data' };
});

export const getCacheStats = functions.https.onCall(async (data, context) => {
  // Verify admin authentication
  if (!context.auth || context.auth.token.email !== 'alenjusufovic@yahoo.com') {
    throw new functions.https.HttpsError('permission-denied', 'Admin access required');
  }
  
  const cacheSnapshot = await db.collection('municipality_cache').get();
  
  return {
    totalCached: cacheSnapshot.size,
    items: cacheSnapshot.docs.map(doc => ({
      municipality: doc.id,
      cachedAt: doc.data().cachedAt?.toDate(),
      expiresAt: doc.data().expiresAt?.toDate(),
    })),
  };
});
```

## Frontend Integration

Update the frontend to call Firebase Functions:

```typescript
// src/lib/google-sheets.ts
import { getFunctions, httpsCallable } from 'firebase/functions';

const functions = getFunctions();

export async function searchMunicipality(name: string): Promise<MunicipalityData | null> {
  const searchFunction = httpsCallable(functions, 'searchMunicipalityAPI');
  const result = await searchFunction({ municipalityName: name });
  return result.data as MunicipalityData | null;
}
```

## Deployment

```bash
# Deploy all functions
firebase deploy --only functions

# Deploy specific function
firebase deploy --only functions:searchMunicipalityAPI
```

## Security Rules

### Firestore Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Municipality cache - read-only for authenticated users
    match /municipality_cache/{document} {
      allow read: if request.auth != null;
      allow write: if false; // Only Cloud Functions can write
    }
    
    // Users collection - private
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Audit log - admin only
    match /audit_log/{document} {
      allow read: if request.auth != null && request.auth.token.email == 'alenjusufovic@yahoo.com';
      allow write: if false; // Only Cloud Functions can write
    }
  }
}
```

## Monitoring & Maintenance

1. **Monitor Function Logs**
   ```bash
   firebase functions:log
   ```

2. **Monitor Cache Hit Rate**
   - Check Firestore usage
   - Monitor Google Sheets API quota

3. **Clean Expired Cache**
   - Set up scheduled function to clean expired cache entries

4. **Monitor PayPal Webhooks**
   - Check webhook delivery status in PayPal dashboard
   - Monitor failed payments

## Cost Optimization

1. **Caching Strategy**
   - 24-hour cache reduces Google Sheets API calls by ~95%
   - Use Firestore for cache storage (cheaper than Realtime Database)

2. **Function Optimization**
   - Use minimum memory allocation
   - Set appropriate timeout values
   - Use Cloud Scheduler for periodic tasks

3. **API Quotas**
   - Google Sheets API: 500 requests per 100 seconds per project
   - With caching: ~20 unique searches per day = 1 API call each
   - Monthly: ~600 API calls (well within free tier)

## Support

For implementation support, contact: info@bh-assistant.ba