# BH PapirFinder - Progressive Web App

## Overview

BH PapirFinder is the first Bosnian multilingual digital tool created by B&H Assistant d.o.o. that helps individuals and organizations quickly find free government forms and documents in Bosnia and Herzegovina.

## Mission Statement

BH PapirFinder is built with good intentions - not to financially exploit users, but to help overcome administrative barriers in Bosnia and Herzegovina's complex bureaucratic structure. Subscription fees are symbolic and used solely to maintain and expand the app's functionality.

## Technology Stack

- **Frontend**: React + TypeScript + Vite
- **UI Framework**: shadcn/ui + Tailwind CSS
- **State Management**: React Context API
- **Routing**: React Router
- **Payment Integration**: PayPal SDK
- **PWA**: Service Worker + Web App Manifest

## Cross-Platform Installation

### PWA Installation (All Platforms)
1. **From Website** (www.bh-assistant.ba):
   - Visit the website
   - Click "Install App" button in the prompt
   - Follow browser-specific installation steps

2. **Android Devices**:
   - Chrome/Edge: Click "Add to Home Screen" from menu
   - Or download from Google Play Store (when published)

3. **iOS Devices**:
   - Safari: Tap Share button → "Add to Home Screen"
   - Or download from Apple App Store (when published)

4. **Desktop**:
   - Chrome/Edge/Safari: Click install icon in address bar
   - Or use "Install BH PapirFinder" from browser menu

### Store Distribution
- **Google Play**: `ba.bh_assistant.papirfinder`
- **Apple App Store**: Coming soon
- **Web**: www.bh-assistant.ba

## Admin Deployment Functions

### Admin Credentials
- **Email**: alenjusufovic@yahoo.com
- **Password**: UmmaIsak2013

### Admin Capabilities
1. **Platform Deployment**:
   - Deploy to www.bh-assistant.ba
   - Publish to Google Play Store
   - Publish to Apple App Store
   - Manage app updates across all platforms

2. **Sponsor Management**:
   - Upload sponsor posters (PNG format)
   - Add/remove sponsor links
   - Manage homepage carousel

3. **Subscription Management**:
   - Configure pricing (10/50/60 BAM)
   - Manage PayPal integration
   - Monitor subscription status

4. **Security Configuration**:
   - Configure API keys
   - Manage allowed domains
   - Update environment variables

## Legal Compliance

BH PapirFinder operates in accordance with the laws of the Federation of Bosnia and Herzegovina (FBiH) and Republika Srpska (RS):

- **Law on Protection of Personal Data of BiH** (aligned with GDPR)
- **Consumer Protection Laws** of FBiH and RS
- **Law on Internal Payment System** of FBiH

## Privacy & Data Protection

### What We DON'T Store:
- ❌ PayPal payment information (processed directly by PayPal)
- ❌ Credit card details
- ❌ Personal identification data
- ❌ Search queries (auto-deleted after 24 hours)

### What We Store Locally:
- ✓ Trial start date (localStorage)
- ✓ Subscription expiry date (localStorage)
- ✓ Login code (localStorage, expires with subscription)
- ✓ Email address (only for login code delivery)

### Automatic Data Deletion:
- Search queries: Deleted after 24 hours
- Login codes: Expire with subscription
- User sessions: Cleared after subscription ends

## Security & API Keys

### Environment Variables

This project uses environment variables to manage API keys securely:

1. **Frontend Keys** (Safe to expose):
   - `VITE_PUBLISHABLE_API_KEY`: Publishable API key for client-side requests
   - `VITE_PAYPAL_CLIENT_ID`: PayPal Client ID for payment UI

2. **Backend Keys** (NEVER expose):
   - `API_SECRET_KEY`: Secret key for server-side validation
   - `PAYPAL_SECRET`: PayPal secret for backend payment processing

### Setup Instructions

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

2. Update the `.env` file with your actual keys (if different from defaults)

3. **IMPORTANT**: Never commit `.env` file to version control. It's already in `.gitignore`.

## Features

- **Free Trial**: 10 days after installation
- **Region-Based Access**: Free access for ZDK (Zenica-Doboj Canton), paid for other regions
- **Multilingual Support**: Bosnian (Latin), Serbian (Cyrillic), English, Turkish, German
- **Subscription Plans**:
  - 10 BAM for 5 days
  - 50 BAM for 30 days
  - 60 BAM for 12 months
- **Document Features**: Download, translate, share, print
- **Admin Panel**: Manage sponsors and application content
- **PWA Support**: Installable, offline-capable, push notifications
- **Homepage Return**: Always-visible button to return to homepage

## Installation

```bash
# Install dependencies
pnpm install

# Run development server
pnpm run dev

# Build for production
pnpm run build

# Preview production build
pnpm run preview
```

## Project Structure

```
src/
├── components/        # Reusable UI components
│   ├── ui/           # shadcn/ui components
│   ├── Header.tsx    # Navigation header with homepage button
│   ├── Footer.tsx    # Site footer
│   ├── InstallPrompt.tsx # PWA installation prompt
│   └── SponsorCarousel.tsx
├── contexts/         # React contexts
│   └── LanguageContext.tsx
├── lib/             # Utilities and configurations
│   ├── config.ts    # App configuration & API keys
│   ├── payment.ts   # Payment integration
│   ├── auth.ts      # Authentication logic
│   ├── regions.ts   # Region-based access control
│   ├── i18n.ts      # Translations
│   └── subscription.ts # Subscription & trial management
├── pages/           # Page components
│   ├── Index.tsx    # Homepage
│   ├── SearchResults.tsx
│   ├── Subscription.tsx
│   ├── Terms.tsx
│   ├── Guide.tsx
│   ├── Support.tsx
│   ├── Privacy.tsx
│   └── Admin.tsx    # Admin panel with deployment functions
└── App.tsx          # Root component
```

## User Experience

### Navigation
- **Homepage Return Button**: Always visible in top-left corner
  - Multilingual labels (Početna/Почетна/Home/Startseite/Ana Sayfa)
  - Accessible on all pages including admin panel
  - Maintains session state when navigating

### Subscription Flow
1. Free trial: 10 days after installation
2. User selects plan and enters email
3. PayPal payment processing
4. Backend generates login code
5. Login code sent via email
6. User profile unlocked with features:
   - Preview of active official websites
   - List of active URLs with descriptions
   - Download forms/documents
   - Translate to: Turkish, English, German, Latin, Cyrillic
   - Share URLs
   - Print documents

## PayPal Integration Workflow

### Frontend (PWA)
1. User enters email and selects subscription plan
2. PayPal button rendered using `VITE_PAYPAL_CLIENT_ID`
3. User completes payment through PayPal modal

### Backend (To Be Implemented)
1. PayPal sends webhook with transaction details
2. Backend validates webhook using `PAYPAL_SECRET`
3. Backend generates unique login code
4. Backend sends login code to user's email
5. User receives access to premium features

## Deployment Guide

### Deploy to www.bh-assistant.ba
1. Build the application: `pnpm run build`
2. Upload `dist/` folder to web server
3. Configure HTTPS and domain
4. Set environment variables
5. Enable service worker

### Publish to Google Play
1. Use Trusted Web Activity (TWA) or PWA Builder
2. Generate signed APK/AAB
3. Upload to Google Play Console
4. Configure app listing and screenshots
5. Submit for review

### Publish to Apple App Store
1. Use PWA Builder or native wrapper
2. Generate iOS app bundle
3. Upload to App Store Connect
4. Configure app metadata
5. Submit for review

## Future Vision

The goal is to evolve BH PapirFinder into a comprehensive multilingual tool that allows every user to find all free forms and documents from all levels of government online, while remaining:
- Fast and efficient
- Affordable (symbolic fees)
- Stress-free to use
- Legally compliant
- Cross-platform accessible

## Contact & Support

- **Email**: info@bh-assistant.ba
- **Website**: www.bh-assistant.ba
- **Company**: B&H Assistant d.o.o., Zenica 72000, BiH

## License

Sva prava zadržana od strane vlasnika aplikacije B&H Assistant d.o.o.
All rights reserved by B&H Assistant d.o.o.

## Contributing

This is a private project owned by B&H Assistant d.o.o. For inquiries, contact info@bh-assistant.ba.

## Compliance & Transparency

BH PapirFinder respects user rights and operates transparently in accordance with BiH laws. We are committed to:
- Protecting user privacy
- Secure payment processing
- Automatic data deletion
- Legal compliance
- Affordable pricing
- Quality service
- Cross-platform accessibility