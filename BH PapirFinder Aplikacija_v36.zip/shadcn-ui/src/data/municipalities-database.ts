// Complete BiH Municipalities Database
// Data extracted from official government sources

export interface MunicipalityData {
  id: string;
  name: string;
  canton?: string;
  region?: string;
  entity: 'FBiH' | 'RS' | 'BD';
  urls: {
    main?: string;
    forms?: string;
    description: string;
  }[];
  categories: string[];
  komentar?: string;
}

export const municipalitiesDatabase: MunicipalityData[] = [
  // ========== FEDERACIJA BiH ==========
  
  // KANTON SARAJEVO (KS)
  {
    id: 'ks-stari-grad',
    name: 'Stari Grad',
    canton: 'Kanton Sarajevo (KS)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://starigrad.ba/bs/obrasci-i-formulari',
        description: 'Formular za punomoć, Izjava o zajedničkom domaćinstvu'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Uvjerenja'],
    komentar: 'Dostupni obrasci za punomoć i zajedničko domaćinstvo'
  },
  {
    id: 'ks-centar',
    name: 'Centar',
    canton: 'Kanton Sarajevo (KS)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://centar.ba/obrasci/',
        description: 'Formular deklaracije OPC-01.1'
      }
    ],
    categories: ['Urbanizam', 'Deklaracije'],
    komentar: 'Formular deklaracije dostupan online'
  },
  {
    id: 'ks-ilidza',
    name: 'Ilidža',
    canton: 'Kanton Sarajevo (KS)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://ilidza.ba/obrasci/',
        description: 'Više PDF obrazaca za različite administrativne postupke'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Uvjerenja'],
    komentar: 'Širok spektar PDF obrazaca dostupan'
  },
  {
    id: 'ks-novi-grad',
    name: 'Novi Grad',
    canton: 'Kanton Sarajevo (KS)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://novigradsa.ba/dokumenti-obrasci/',
        description: 'Obrasci - prijava prebivališta, ličnih dokumenata i sl.'
      }
    ],
    categories: ['Matični uredi', 'Prijava prebivališta', 'Lični dokumenti'],
    komentar: 'Obrasci za prijavu prebivališta i lična dokumenta'
  },
  {
    id: 'ks-novo-sarajevo',
    name: 'Novo Sarajevo',
    canton: 'Kanton Sarajevo (KS)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://novosarajevo.ba/obrasci/',
        description: 'Obrazci, formulari za fizička i pravna lica iz raznih oblasti'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Uvjerenja', 'Pravna lica'],
    komentar: 'Obrasci za fizička i pravna lica'
  },
  {
    id: 'ks-vogosca',
    name: 'Vogošća',
    canton: 'Kanton Sarajevo (KS)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://vogosca.ba/',
        description: 'E-formulari kroz centralnu e-upravu (nisu javno listani PDF-ovima)'
      }
    ],
    categories: ['E-uprava', 'Interaktivni formulari'],
    komentar: 'Koristi centralizovane e-upravne portale'
  },
  {
    id: 'grad-sarajevo',
    name: 'Grad Sarajevo',
    canton: 'Kanton Sarajevo (KS)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://sarajevo.ba/bs/obrasci/',
        description: 'Obrasci – zahtjev za uvjerenja, urbanistička saglasnost, lokacijska informacija'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja', 'Lokacijska informacija'],
    komentar: 'Glavni grad - sveobuhvatni obrasci'
  },

  // ZENIČKO-DOBOJSKI KANTON (ZDK)
  {
    id: 'zdk-zenica',
    name: 'Zenica',
    canton: 'Zeničko-dobojski kanton (ZDK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://zenica.ba/pdf-formular-zzo-zdk/',
        description: 'PDF formular ZZO ZDK'
      },
      {
        main: 'https://zenica.ba/e-registar-administrativnih-postupaka/',
        description: 'E-registar Administrativnih postupaka'
      },
      {
        main: 'https://zenica.ba/e-servis/',
        description: 'E-Servis PDF razni administrativni formulari i obrazci'
      }
    ],
    categories: ['Zdravstvo', 'E-uprava', 'Administrativni postupci'],
    komentar: 'Digitalizovani sistem sa e-servisom'
  },
  {
    id: 'zdk-doboj-jug',
    name: 'Doboj-Jug',
    canton: 'Zeničko-dobojski kanton (ZDK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://doboj-jug.ba/pdf-formular-zzo-zdk/',
        description: 'PDF formular ZZO ZDK'
      }
    ],
    categories: ['Zdravstvo'],
    komentar: 'Zdravstveni obrasci ZZO ZDK'
  },
  {
    id: 'zdk-kakanj',
    name: 'Kakanj',
    canton: 'Zeničko-dobojski kanton (ZDK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://kakanj.ba/pdf-formular-zzo-zdk/',
        description: 'PDF formular ZZO ZDK'
      }
    ],
    categories: ['Zdravstvo'],
    komentar: 'Zdravstveni obrasci ZZO ZDK'
  },
  {
    id: 'zdk-maglaj',
    name: 'Maglaj',
    canton: 'Zeničko-dobojski kanton (ZDK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://maglaj.ba/pdf-formular-zzo-zdk/',
        description: 'PDF formular ZZO ZDK'
      }
    ],
    categories: ['Zdravstvo'],
    komentar: 'Zdravstveni obrasci ZZO ZDK'
  },
  {
    id: 'zdk-zepce',
    name: 'Žepče',
    canton: 'Zeničko-dobojski kanton (ZDK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://zepce.ba/pdf-formular-zzo-zdk/',
        description: 'PDF formular ZZO ZDK'
      }
    ],
    categories: ['Zdravstvo'],
    komentar: 'Zdravstveni obrasci ZZO ZDK'
  },
  {
    id: 'zdk-tesanj',
    name: 'Tešanj',
    canton: 'Zeničko-dobojski kanton (ZDK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://tesanj.ba/pdf-formular-zzo-zdk/',
        description: 'PDF formular ZZO ZDK'
      }
    ],
    categories: ['Zdravstvo'],
    komentar: 'Zdravstveni obrasci ZZO ZDK'
  },
  {
    id: 'grad-zenica',
    name: 'Grad Zenica',
    canton: 'Zeničko-dobojski kanton (ZDK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://zenica.ba/obrasci/',
        description: 'Obrasci – urbanizam, matični uredi, izdavanje uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Uvjerenja'],
    komentar: 'Sveobuhvatni gradski obrasci'
  },

  // TUZLANSKI KANTON (TK)
  {
    id: 'grad-tuzla',
    name: 'Grad Tuzla',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://grad.tuzla.ba/obrasci/',
        description: 'Razni administrativni formulari za građane iz područja opće uprave'
      },
      {
        main: 'https://grad.tuzla.ba/formular-izvod-maticne-knjige/',
        description: 'Formular za izvod iz matičnih knjiga'
      }
    ],
    categories: ['Opća uprava', 'Matični uredi', 'Uvjerenja'],
    komentar: 'Obrasci – zahtjev za uvjerenja, urbanizam, prijava boravka'
  },
  {
    id: 'tk-kalesija',
    name: 'Kalesija',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://kalesija.ba/e-formulari/',
        description: 'Elektronski formulari za: upis rođenja, prijava zdravstvenog osiguranja, punomoć, kućna lista'
      },
      {
        main: 'https://kalesija.ba/lokacijska-informacija/',
        description: 'Lokacijska informacija'
      },
      {
        main: 'https://kalesija.ba/uvjerenje-urbanizam/',
        description: 'Uvjerenje iz urbanističkih odsjeka'
      }
    ],
    categories: ['E-formulari', 'Matični uredi', 'Urbanizam', 'Zdravstvo'],
    komentar: 'Digitalizovani e-formulari za različite usluge'
  },
  {
    id: 'tk-banovici',
    name: 'Banovići',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://banovici.ba/obrasci/',
        description: 'Obrasci – zahtjev za urbanističku saglasnost, lokacijsku informaciju, uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja'],
    komentar: 'Urbanistički obrasci i uvjerenja'
  },
  {
    id: 'tk-celic',
    name: 'Čelić',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://celic.ba/obrasci/',
        description: 'Obrasci – zahtjev za socijalnu pomoć, zahtjev za uvjerenja, građevinske dozvole'
      }
    ],
    categories: ['Socijalna zaštita', 'Uvjerenja', 'Građevinske dozvole'],
    komentar: 'Obrasci za socijalnu pomoć i građevinske dozvole'
  },
  {
    id: 'tk-doboj-istok',
    name: 'Doboj Istok',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://doboj-istok.ba/obrasci/',
        description: 'Obrasci – prijava prebivališta, izdavanje uvjerenja, zahtjevi prema urbanizmu'
      }
    ],
    categories: ['Prijava prebivališta', 'Uvjerenja', 'Urbanizam'],
    komentar: 'Jedna od rijetkih općina sa mogućnošću online naručivanja dokumenata'
  },
  {
    id: 'tk-gracanica',
    name: 'Gračanica',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://gracanica.ba/obrasci/',
        description: 'Obrasci – lokacijska informacija, urbanistička saglasnost, zahtjev za uvid u dokumente'
      }
    ],
    categories: ['Urbanizam', 'Lokacijska informacija'],
    komentar: 'Urbanistički obrasci i lokacijske informacije'
  },
  {
    id: 'tk-gradacac',
    name: 'Gradačac',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://gradacac.ba/obrasci/',
        description: 'Obrasci – zahtjev za izdavanje izvoda, uvjerenja, lokacijska informacija'
      }
    ],
    categories: ['Matični uredi', 'Uvjerenja', 'Urbanizam'],
    komentar: 'Izvodi, uvjerenja i lokacijske informacije'
  },
  {
    id: 'tk-kladanj',
    name: 'Kladanj',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://kladanj.ba/obrasci/',
        description: 'Obrasci – socijalna davanja, urbanizam, matični uredi'
      }
    ],
    categories: ['Socijalna zaštita', 'Urbanizam', 'Matični uredi'],
    komentar: 'Socijalna davanja i matični uredi'
  },
  {
    id: 'tk-lukavac',
    name: 'Lukavac',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://lukavac.ba/obrasci/',
        description: 'Obrasci – uvjerenja, lokacijska informacija, urbanizam'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam'],
    komentar: 'Uvjerenja i urbanistički obrasci'
  },
  {
    id: 'tk-sapna',
    name: 'Sapna',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://opcina-sapna.ba/dokumenti/',
        description: 'Obrasci – zahtjevi za uvjerenja, urbanistička dokumentacija'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam'],
    komentar: 'Uvjerenja i urbanistička dokumentacija'
  },
  {
    id: 'tk-srebrenik',
    name: 'Srebrenik',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://srebrenik.ba/obrasci/',
        description: 'Obrasci – urbanistička saglasnost, lokacijska informacija, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi'],
    komentar: 'Urbanistička saglasnost i matični uredi'
  },
  {
    id: 'tk-teocak',
    name: 'Teočak',
    canton: 'Tuzlanski kanton (TK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://teocak.ba/obrasci/',
        description: 'Obrasci – zahtjevi građana, izdavanje uvjerenja'
      }
    ],
    categories: ['Uvjerenja', 'Zahtjevi građana'],
    komentar: 'Zahtjevi građana i uvjerenja'
  },

  // UNSKO-SANSKI KANTON (USK)
  {
    id: 'grad-bihac',
    name: 'Grad Bihać',
    canton: 'Unsko-sanski kanton (USK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://bihac.org/obrasci/',
        description: 'Obrasci i zahtjevi, izjave, prijave – razni obrasci za urbanizam, matične knjige, uvjerenja, lokacijske informacije'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Uvjerenja', 'Lokacijska informacija'],
    komentar: 'Obrasci – urbanistička saglasnost, izdavanje uvjerenja'
  },
  {
    id: 'usk-bosanska-krupa',
    name: 'Bosanska Krupa',
    canton: 'Unsko-sanski kanton (USK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://bosanska-krupa.ba/obrasci/',
        description: 'Obrasci – lokacijska informacija, urbanistička saglasnost, građevinske dozvole'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole'],
    komentar: 'Urbanistička saglasnost i građevinske dozvole'
  },
  {
    id: 'usk-buzim',
    name: 'Bužim',
    canton: 'Unsko-sanski kanton (USK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://buzim.ba/obrasci/',
        description: 'Obrasci – prijava prebivališta, izdavanje uvjerenja, socijalna davanja'
      }
    ],
    categories: ['Prijava prebivališta', 'Uvjerenja', 'Socijalna zaštita'],
    komentar: 'Prijava prebivališta i socijalna davanja'
  },
  {
    id: 'usk-cazin',
    name: 'Cazin',
    canton: 'Unsko-sanski kanton (USK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://cazin.ba/obrasci/',
        description: 'Obrasci – urbanizam, matični uredi, izdavanje izvoda i uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Uvjerenja'],
    komentar: 'Urbanizam, matični uredi i uvjerenja'
  },
  {
    id: 'usk-kljuc',
    name: 'Ključ',
    canton: 'Unsko-sanski kanton (USK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://kljuc.ba/obrasci/',
        description: 'Obrasci – prijave, zahtjevi za dozvole, urbanizam'
      }
    ],
    categories: ['Urbanizam', 'Dozvole'],
    komentar: 'Prijave i zahtjevi za dozvole'
  },
  {
    id: 'usk-sanski-most',
    name: 'Sanski Most',
    canton: 'Unsko-sanski kanton (USK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://sanski-most.ba/obrasci/',
        description: 'Obrasci – izdavanje izvoda iz matičnih knjiga, urbanizam, lokacijska informacija'
      }
    ],
    categories: ['Matični uredi', 'Urbanizam'],
    komentar: 'Matični uredi i urbanizam'
  },
  {
    id: 'usk-velika-kladusa',
    name: 'Velika Kladuša',
    canton: 'Unsko-sanski kanton (USK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://velika-kladusa.ba/obrasci/',
        description: 'Obrasci – urbanistička saglasnost, zahtjev za izdavanje uvjerenja, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja', 'Matični uredi'],
    komentar: 'Urbanistička saglasnost i matični uredi'
  },

  // SREDNJOBOSANSKI KANTON (SBK)
  {
    id: 'sbk-travnik',
    name: 'Travnik',
    canton: 'Srednjobosanski kanton (SBK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://travnik.ba/obrasci/',
        description: 'Obrasci – urbanistička saglasnost, lokacijska informacija, izdavanje uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja'],
    komentar: 'Urbanistička saglasnost i uvjerenja'
  },
  {
    id: 'sbk-bugojno',
    name: 'Bugojno',
    canton: 'Srednjobosanski kanton (SBK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://bugojno.ba/obrasci/',
        description: 'Obrasci – urbanizam, građevinske dozvole, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Urbanizam i građevinske dozvole'
  },
  {
    id: 'sbk-gornji-vakuf',
    name: 'Gornji Vakuf-Uskoplje',
    canton: 'Srednjobosanski kanton (SBK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://gv-uskoplje.ba/e-maticar/',
        description: 'E-Matičar omogućava online podnošenje zahtjeva za izdavanje i dostavu izvoda i uvjerenja'
      }
    ],
    categories: ['E-matičar', 'Matični uredi'],
    komentar: 'Online E-Matičar sistem'
  },
  {
    id: 'sbk-donji-vakuf',
    name: 'Donji Vakuf',
    canton: 'Srednjobosanski kanton (SBK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://donji-vakuf.ba/obrasci/',
        description: 'Obrasci – urbanističke saglasnosti, izdavanje uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja'],
    komentar: 'Urbanističke saglasnosti i uvjerenja'
  },
  {
    id: 'sbk-novi-travnik',
    name: 'Novi Travnik',
    canton: 'Srednjobosanski kanton (SBK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://novi-travnik.ba/obrasci/',
        description: 'Obrasci – zahtjevi za uvjerenja, urbanistička dokumentacija'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam'],
    komentar: 'Uvjerenja i urbanistička dokumentacija'
  },
  {
    id: 'sbk-vitez',
    name: 'Vitez',
    canton: 'Srednjobosanski kanton (SBK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://vitez.ba/obrasci/',
        description: 'Obrasci – lokacijska informacija, urbanizam'
      }
    ],
    categories: ['Urbanizam', 'Lokacijska informacija'],
    komentar: 'Lokacijska informacija i urbanizam'
  },
  {
    id: 'sbk-busovaca',
    name: 'Busovača',
    canton: 'Srednjobosanski kanton (SBK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://busovaca.ba/obrasci/',
        description: 'Obrasci – zahtjevi za uvjerenja, urbanizam'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam'],
    komentar: 'Zahtjevi za uvjerenja i urbanizam'
  },
  {
    id: 'sbk-kiseljak',
    name: 'Kiseljak',
    canton: 'Srednjobosanski kanton (SBK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://kiseljak.ba/obrasci/',
        description: 'Obrasci – urbanistička saglasnost, izdavanje uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja'],
    komentar: 'Urbanistička saglasnost i uvjerenja'
  },
  {
    id: 'sbk-kresevo',
    name: 'Kreševo',
    canton: 'Srednjobosanski kanton (SBK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://kresevo.ba/obrasci/',
        description: 'Obrasci – izdavanje uvjerenja, urbanizam. Dokumenti se dostavljaju poštom.'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam'],
    komentar: 'Dokumenti se dostavljaju preporučeno poštom'
  },
  {
    id: 'sbk-fojnica',
    name: 'Fojnica',
    canton: 'Srednjobosanski kanton (SBK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://fojnica.ba/obrasci/',
        description: 'Obrasci – urbanističke saglasnosti, izdavanje uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja'],
    komentar: 'Urbanističke saglasnosti i uvjerenja'
  },

  // HERCEGOVAČKO-NERETVANSKI KANTON (HNK)
  {
    id: 'grad-mostar',
    name: 'Grad Mostar',
    canton: 'Hercegovačko-neretvanski kanton (HNK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://mostar.ba/obrasci/',
        description: 'Obrasci – urbanizam, uvjerenja, matični uredi, socijalna zaštita'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja', 'Matični uredi', 'Socijalna zaštita'],
    komentar: 'Obrasci – urbanizam, izdavanje uvjerenja, prijava boravka'
  },
  {
    id: 'hnk-capljina',
    name: 'Čapljina',
    canton: 'Hercegovačko-neretvanski kanton (HNK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://capljina.ba/obrasci/',
        description: 'Obrasci – lokacijska informacija, urbanistička saglasnost, izvod iz matičnih knjiga'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi'],
    komentar: 'Lokacijska informacija i matični uredi'
  },
  {
    id: 'hnk-citluk',
    name: 'Čitluk',
    canton: 'Hercegovačko-neretvanski kanton (HNK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://citluk.ba/obrasci/',
        description: 'Obrasci – izdavanje uvjerenja, urbanističke saglasnosti'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam'],
    komentar: 'Uvjerenja i urbanističke saglasnosti'
  },
  {
    id: 'hnk-jablanica',
    name: 'Jablanica',
    canton: 'Hercegovačko-neretvanski kanton (HNK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://jablanica.ba/obrasci/',
        description: 'Obrasci – zahtjev za uvjerenje, urbanizam, matični uredi'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam', 'Matični uredi'],
    komentar: 'Uvjerenja, urbanizam i matični uredi'
  },
  {
    id: 'hnk-konjic',
    name: 'Konjic',
    canton: 'Hercegovačko-neretvanski kanton (HNK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://konjic.ba/obrasci/',
        description: 'Obrasci – lokacijska informacija, građevinske dozvole, uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Uvjerenja'],
    komentar: 'Lokacijska informacija i građevinske dozvole'
  },
  {
    id: 'hnk-neum',
    name: 'Neum',
    canton: 'Hercegovačko-neretvanski kanton (HNK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://neum.ba/obrasci/',
        description: 'Obrasci – zahtjev za uvjerenja, urbanistička dokumentacija'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam'],
    komentar: 'Uvjerenja i urbanistička dokumentacija'
  },
  {
    id: 'hnk-prozor-rama',
    name: 'Prozor-Rama',
    canton: 'Hercegovačko-neretvanski kanton (HNK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://prozor-rama.ba/obrasci/',
        description: 'Obrasci – zahtjev za izdavanje izvoda, urbanizam'
      }
    ],
    categories: ['Matični uredi', 'Urbanizam'],
    komentar: 'Izdavanje izvoda i urbanizam'
  },
  {
    id: 'hnk-stolac',
    name: 'Stolac',
    canton: 'Hercegovačko-neretvanski kanton (HNK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://stolac.ba/obrasci/',
        description: 'Obrasci – zahtjevi za uvjerenja, urbanistička dokumentacija'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam'],
    komentar: 'Uvjerenja i urbanistička dokumentacija'
  },

  // POSAVSKI KANTON (PK)
  {
    id: 'pk-orasje',
    name: 'Orašje',
    canton: 'Posavski kanton (PK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://orasje.ba/obrasci/',
        description: 'Obrasci – zahtjev za uvjerenja, urbanistička saglasnost, lokacijska informacija'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam'],
    komentar: 'Uvjerenja i urbanistička saglasnost'
  },
  {
    id: 'pk-odzak',
    name: 'Odžak',
    canton: 'Posavski kanton (PK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://odzak.ba/obrasci/',
        description: 'Obrasci – urbanističke saglasnosti, izdavanje uvjerenja, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja', 'Matični uredi'],
    komentar: 'Urbanističke saglasnosti i matični uredi'
  },
  {
    id: 'pk-domaljevac-samac',
    name: 'Domaljevac-Šamac',
    canton: 'Posavski kanton (PK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://domaljevac-samac.ba/',
        description: 'Nema posebnu stranicu za obrasce, dostupno putem protokola općine'
      }
    ],
    categories: ['Protokol općine'],
    komentar: 'Obrasci dostupni putem protokola općine'
  },

  // KANTON 10 - LIVANJSKI (K10)
  {
    id: 'grad-livno',
    name: 'Grad Livno',
    canton: 'Kanton 10 (Livanjski)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://livno.ba/obrasci/',
        description: 'Obrasci i zahtjevi – urbanizam, lokacijska informacija, izdavanje uvjerenja, socijalna pomoć'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja', 'Socijalna zaštita'],
    komentar: 'Dokumenti se šalju poštom nakon konfirmacije'
  },
  {
    id: 'k10-tomislavgrad',
    name: 'Tomislavgrad',
    canton: 'Kanton 10 (Livanjski)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://tomislavgrad.ba/obrasci/',
        description: 'Obrasci – urbanističke saglasnosti, lokacijska informacija, zahtjevi za uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja'],
    komentar: 'Urbanističke saglasnosti i uvjerenja'
  },
  {
    id: 'k10-drvar',
    name: 'Drvar',
    canton: 'Kanton 10 (Livanjski)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://drvar.ba/obrasci/',
        description: 'Obrazci, prijave, zahtjevi pravno imovinski, porodiljske naknade i ostalo u PDF i MSW'
      }
    ],
    categories: ['Pravno-imovinski', 'Socijalna zaštita'],
    komentar: 'Website može zahtijevati SSL konfiguraciju'
  },

  // ZAPADNOHERCEGOVAČKI KANTON (ZHK)
  {
    id: 'grad-siroki-brijeg',
    name: 'Grad Široki Brijeg',
    canton: 'Zapadnohercegovački kanton (ZHK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://siroki-brijeg.ba/obrasci/',
        description: 'Obrasci – urbanistička saglasnost, lokacijska informacija, izdavanje uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja'],
    komentar: 'Obrasci – lokacijska informacija, urbanizam, uvjerenja'
  },
  {
    id: 'grad-ljubuski',
    name: 'Grad Ljubuški',
    canton: 'Zapadnohercegovački kanton (ZHK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://ljubuski.ba/obrasci/',
        description: 'Obrasci – urbanističke saglasnosti, uvjerenja, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja', 'Matični uredi'],
    komentar: 'Obrasci – urbanističke saglasnosti, matični uredi, izdavanje uvjerenja'
  },
  {
    id: 'zhk-grude',
    name: 'Grude',
    canton: 'Zapadnohercegovački kanton (ZHK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://grude.ba/obrasci/',
        description: 'Obrasci – urbanizam, građevinske dozvole, izdavanje uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Uvjerenja'],
    komentar: 'Urbanizam i građevinske dozvole'
  },
  {
    id: 'zhk-posusje',
    name: 'Posušje',
    canton: 'Zapadnohercegovački kanton (ZHK)',
    entity: 'FBiH',
    urls: [
      {
        main: 'https://posusje.ba/obrasci/',
        description: 'Obrasci – zahtjevi za urbanizam, izdavanje uvjerenja, lokacijske informacije'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja'],
    komentar: 'Urbanizam i izdavanje uvjerenja'
  },

  // ========== REPUBLIKA SRPSKA ==========

  // RS #1 - BANJALUČKA REGIJA
  {
    id: 'grad-banja-luka',
    name: 'Grad Banja Luka',
    region: 'Banjalučka regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://banjaluka.rs.ba/obrasci/',
        description: 'Obrasci – urbanistička saglasnost, lokacijska informacija, uvjerenja o prebivalištu, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja', 'Matični uredi'],
    komentar: 'Obrasci – urbanistička saglasnost, lokacijska informacija, uvjerenja'
  },
  {
    id: 'rs-laktasi',
    name: 'Laktaši',
    region: 'Banjalučka regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://laktasi.org/obrasci/',
        description: 'Obrasci – urbanizam, zahtjev za uvjerenje o državljanstvu, prijava boravka'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja', 'Prijava boravka'],
    komentar: 'Urbanizam i prijava boravka'
  },
  {
    id: 'rs-gradiska',
    name: 'Gradiška',
    region: 'Banjalučka regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://gradiska.org/obrasci/',
        description: 'Obrasci za poljoprivredu, privredu, boračko invalidska zaštita, prostorno uređenje. Zahtjevi za izvode iz matičnih knjiga.'
      }
    ],
    categories: ['Matični uredi', 'Urbanizam', 'Poljoprivreda', 'Boračko-invalidska zaštita'],
    komentar: 'Širok spektar obrazaca uključujući matične knjige'
  },
  {
    id: 'rs-prnjavor',
    name: 'Prnjavor',
    region: 'Banjalučka regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://prnjavor.org/obrasci/',
        description: 'Obrasci – urbanizam, prijava boravka, uvjerenja iz matičnih knjiga'
      }
    ],
    categories: ['Urbanizam', 'Prijava boravka', 'Matični uredi'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-kotor-varos',
    name: 'Kotor Varoš',
    region: 'Banjalučka regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://kotor-varos.com/obrasci/',
        description: 'Obrasci – lokacijska informacija, građevinske dozvole, matični uredi, rodni list'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Lokacijska informacija i matični uredi'
  },
  {
    id: 'rs-knezevo',
    name: 'Kneževo (Skender Vakuf)',
    region: 'Banjalučka regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://knezevo.org/obrasci/',
        description: 'Obrasci – urbanizam, zahtjevi za dozvole iz domena poljoprivrede, registracije obrta'
      }
    ],
    categories: ['Urbanizam', 'Poljoprivreda', 'Registracije'],
    komentar: 'Urbanizam i poljoprivreda'
  },
  {
    id: 'rs-mrkonjic-grad',
    name: 'Mrkonjić Grad',
    region: 'Banjalučka regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://mrkonjicgrad.org/obrasci/',
        description: 'Obrasci – urbanističke saglasnosti, izdavanje uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja'],
    komentar: 'Obrasci na dnu naslovne stranice'
  },
  {
    id: 'rs-novi-grad',
    name: 'Novi Grad (Bosanski Novi)',
    region: 'Banjalučka regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://novi-grad.org/obrasci/',
        description: 'Obrasci – urbanizam, uvjerenja, matični uredi, rodni list, smrtni list'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja', 'Matični uredi'],
    komentar: 'Urbanizam i matični uredi'
  },

  // RS #2 - PRIJEDORSKA REGIJA
  {
    id: 'grad-prijedor',
    name: 'Grad Prijedor',
    region: 'Prijedorska regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://prijedor.org/obrasci/',
        description: 'Obrasci – urbanizam, građevinske dozvole, uvjerenja o prebivalištu, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Obrasci – urbanizam, građevinske dozvole, uvjerenja'
  },
  {
    id: 'rs-kozarska-dubica',
    name: 'Kozarska Dubica',
    region: 'Prijedorska regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://kozarska-dubica.com/obrasci/',
        description: 'Obrasci – urbanistička saglasnost, građevinske dozvole, prijava prebivališta'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Prijava prebivališta'],
    komentar: 'Urbanistička saglasnost i građevinske dozvole'
  },
  {
    id: 'rs-ostra-luka',
    name: 'Oštra Luka',
    region: 'Prijedorska regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://ostra-luka.org/obrasci/',
        description: 'Obrasci – urbanistička saglasnost, prijava prebivališta, uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Prijava prebivališta', 'Uvjerenja'],
    komentar: 'Urbanistička saglasnost i prijava prebivališta'
  },

  // RS #3 - DOBOJ REGIJA
  {
    id: 'grad-doboj',
    name: 'Grad Doboj',
    region: 'Doboj regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://doboj.gov.ba/obrasci-i-zahtjevi/',
        description: 'Obrasci – urbanizam, lokacijska informacija, građevinske dozvole, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-teslic',
    name: 'Teslić',
    region: 'Doboj regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://teslic.rs.ba/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanistička saglasnost, građevinske dozvole, uvjerenja iz matičnih knjiga'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Urbanistička saglasnost i matični uredi'
  },
  {
    id: 'rs-modrica',
    name: 'Modriča',
    region: 'Doboj regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://modrica.ba/usluge/obrasci/',
        description: 'Obrasci – urbanizam, prijava boravka, uvjerenja o prebivalištu'
      }
    ],
    categories: ['Urbanizam', 'Prijava boravka', 'Uvjerenja'],
    komentar: 'Urbanizam i prijava boravka'
  },
  {
    id: 'rs-derventa',
    name: 'Derventa',
    region: 'Doboj regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://derventa.ba/usluge/obrasci/',
        description: 'Obrasci – zahtjevi za uvjerenja, urbanističke saglasnosti, prijava prebivališta'
      }
    ],
    categories: ['Uvjerenja', 'Urbanizam', 'Prijava prebivališta'],
    komentar: 'Uvjerenja i urbanističke saglasnosti'
  },
  {
    id: 'rs-brod',
    name: 'Brod',
    region: 'Doboj regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://opstina-brod.net/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, prijava boravka, uvjerenja iz matičnih knjiga'
      }
    ],
    categories: ['Urbanizam', 'Prijava boravka', 'Matični uredi'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-vukosavlje',
    name: 'Vukosavlje',
    region: 'Doboj regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://vukosavlje.org/obrasci/',
        description: 'Obrasci – prijava prebivališta, urbanizam, matični uredi'
      }
    ],
    categories: ['Prijava prebivališta', 'Urbanizam', 'Matični uredi'],
    komentar: 'Prijava prebivališta i matični uredi'
  },
  {
    id: 'rs-petrovo',
    name: 'Petrovo',
    region: 'Doboj regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://opstinapetrovo.org/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, uvjerenja o prebivalištu, građevinske dozvole'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja', 'Građevinske dozvole'],
    komentar: 'Urbanizam i građevinske dozvole'
  },
  {
    id: 'rs-samac',
    name: 'Šamac',
    region: 'Doboj regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://opstinasamac.org/obrasci/',
        description: 'Obrasci – urbanizam, matični uredi, prijava boravka'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Prijava boravka'],
    komentar: 'Urbanizam i matični uredi'
  },

  // RS #4 - BIJELJINA REGIJA
  {
    id: 'grad-bijeljina',
    name: 'Grad Bijeljina',
    region: 'Bijeljina regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://bijeljina.org/lat/zahtjevi-i-obrasci.html',
        description: 'Obrasci – urbanizam, lokacijska informacija, građevinske dozvole, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Obrasci – urbanističke saglasnosti, uvjerenja, matični uredi'
  },
  {
    id: 'rs-ugljevik',
    name: 'Ugljevik',
    region: 'Bijeljina regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://ugljevik.rs.ba/usluge/obrasci/',
        description: 'Obrasci – urbanistička saglasnost, prijava prebivališta, uvjerenja iz matičnih knjiga'
      }
    ],
    categories: ['Urbanizam', 'Prijava prebivališta', 'Matični uredi'],
    komentar: 'Urbanistička saglasnost i matični uredi'
  },
  {
    id: 'rs-lopare',
    name: 'Lopare',
    region: 'Bijeljina regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://lopare.rs.ba/zahtjevi-i-obrasci/',
        description: 'Obrasci – lokacijska informacija, urbanizam, uvjerenja o prebivalištu'
      }
    ],
    categories: ['Urbanizam', 'Uvjerenja'],
    komentar: 'Lokacijska informacija i uvjerenja'
  },
  {
    id: 'rs-zvornik',
    name: 'Zvornik',
    region: 'Bijeljina regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://opstina-zvornik.org/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, matični uredi, prijava boravka'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Prijava boravka'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-sekovici',
    name: 'Šekovići',
    region: 'Bijeljina regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://sekovici.org/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanističke saglasnosti, matični uredi, uvjerenja o prebivalištu'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Uvjerenja'],
    komentar: 'Urbanističke saglasnosti i matični uredi'
  },
  {
    id: 'rs-osmaci',
    name: 'Osmaci',
    region: 'Bijeljina regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://osmaci.org/obrasci/',
        description: 'Obrasci – prijava prebivališta, urbanizam, matični uredi'
      }
    ],
    categories: ['Prijava prebivališta', 'Urbanizam', 'Matični uredi'],
    komentar: 'Prijava prebivališta i matični uredi'
  },

  // RS #5 - ISTOČNO SARAJEVO REGIJA
  {
    id: 'grad-istocno-sarajevo',
    name: 'Grad Istočno Sarajevo',
    region: 'Istočno Sarajevo regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://gradistocnosarajevo.net/usluge/obrasci/',
        description: 'Obrasci – urbanizam, lokacijska informacija, građevinske dozvole, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-istocna-ilidza',
    name: 'Istočna Ilidža',
    region: 'Istočno Sarajevo regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://istocnailidza.net/usluge/obrasci/',
        description: 'Obrasci – urbanistička saglasnost, prijava prebivališta, uvjerenja o državljanstvu'
      }
    ],
    categories: ['Urbanizam', 'Prijava prebivališta', 'Uvjerenja'],
    komentar: 'Urbanistička saglasnost i prijava prebivališta'
  },
  {
    id: 'rs-istocno-novo-sarajevo',
    name: 'Istočno Novo Sarajevo',
    region: 'Istočno Sarajevo regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://istocnonovosarajevo.rs.ba/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, lokacijska informacija, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-pale',
    name: 'Pale',
    region: 'Istočno Sarajevo regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://opstinapale.org/zahtjevi-i-obrasci/',
        description: 'Obrasci – građevinske dozvole, urbanističke saglasnosti, matični uredi'
      }
    ],
    categories: ['Građevinske dozvole', 'Urbanizam', 'Matični uredi'],
    komentar: 'Građevinske dozvole i matični uredi'
  },
  {
    id: 'rs-trnovo',
    name: 'Trnovo (RS)',
    region: 'Istočno Sarajevo regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://trnovo-rs.org/obrasci/',
        description: 'Obrasci – urbanizam, prijava prebivališta, uvjerenja'
      }
    ],
    categories: ['Urbanizam', 'Prijava prebivališta', 'Uvjerenja'],
    komentar: 'Urbanizam i prijava prebivališta'
  },
  {
    id: 'rs-istocni-stari-grad',
    name: 'Istočni Stari Grad',
    region: 'Istočno Sarajevo regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://istocnistarigrad.org/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, matični uredi, prijava boravka'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Prijava boravka'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-sokolac',
    name: 'Sokolac',
    region: 'Istočno Sarajevo regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://opstinasokolac.net/obrasci-i-zahtjevi/',
        description: 'Obrasci – urbanizam, građevinske dozvole, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Urbanizam i građevinske dozvole'
  },

  // RS #6 - TREBINJE REGIJA
  {
    id: 'grad-trebinje',
    name: 'Grad Trebinje',
    region: 'Trebinje regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://trebinje.rs.ba/obrasci-i-zahtjevi/',
        description: 'Obrasci – urbanizam, građevinske dozvole, lokacijska informacija, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Obrasci – urbanizam, lokacijska informacija, izdavanje uvjerenja'
  },
  {
    id: 'rs-bileca',
    name: 'Bileća',
    region: 'Trebinje regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://bileca.rs.ba/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanistička saglasnost, matični uredi, prijava prebivališta'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Prijava prebivališta'],
    komentar: 'Urbanistička saglasnost i matični uredi'
  },
  {
    id: 'rs-gacko',
    name: 'Gacko',
    region: 'Trebinje regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://gacko-rs.info/obrasci/',
        description: 'Obrasci – urbanizam, građevinske dozvole, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Urbanizam i građevinske dozvole'
  },
  {
    id: 'rs-nevesinje',
    name: 'Nevesinje',
    region: 'Trebinje regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://opstinanevesinje.rs.ba/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, lokacijska informacija, uvjerenja iz matičnih knjiga'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-ljubinje',
    name: 'Ljubinje',
    region: 'Trebinje regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://ljubinje.org/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, prijava prebivališta, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Prijava prebivališta', 'Matični uredi'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-berkovici',
    name: 'Berkovići',
    region: 'Trebinje regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://berkovici.rs.ba/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, matični uredi, građevinske dozvole'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Građevinske dozvole'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-istocni-mostar',
    name: 'Istočni Mostar',
    region: 'Trebinje regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://istocnimostar.org/obrasci/',
        description: 'Obrasci – prijava prebivališta, matični uredi, urbanizam'
      }
    ],
    categories: ['Prijava prebivališta', 'Matični uredi', 'Urbanizam'],
    komentar: 'Prijava prebivališta i matični uredi'
  },

  // RS #7 - FOČA REGIJA
  {
    id: 'rs-foca',
    name: 'Foča',
    region: 'Foča regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://opstinafoca.rs.ba/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, lokacijska informacija, građevinske dozvole, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-cajnice',
    name: 'Čajniče',
    region: 'Foča regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://cajnice.rs.ba/obrasci/',
        description: 'Obrasci – urbanizam, matični uredi, prijava prebivališta'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Prijava prebivališta'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-rudo',
    name: 'Rudo',
    region: 'Foča regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://rudo.rs.ba/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, građevinske dozvole, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Urbanizam i građevinske dozvole'
  },
  {
    id: 'rs-novo-gorazde',
    name: 'Novo Goražde',
    region: 'Foča regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://novogorazde.rs.ba/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanizam, prijava prebivališta, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Prijava prebivališta', 'Matični uredi'],
    komentar: 'Urbanizam i matični uredi'
  },

  // RS #8 - SARAJEVO-ROMANIJSKA REGIJA
  {
    id: 'rs-han-pijesak',
    name: 'Han Pijesak',
    region: 'Sarajevo-romanijska regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://hanpijesak.org/obrasci-i-zahtjevi/',
        description: 'Obrasci – urbanizam, matični uredi, prijava prebivališta'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Prijava prebivališta'],
    komentar: 'Urbanizam i matični uredi'
  },
  {
    id: 'rs-rogatica',
    name: 'Rogatica',
    region: 'Sarajevo-romanijska regija',
    entity: 'RS',
    urls: [
      {
        main: 'https://rogatica.rs.ba/zahtjevi-i-obrasci/',
        description: 'Obrasci – urbanističke saglasnosti, građevinske dozvole, matični uredi'
      }
    ],
    categories: ['Urbanizam', 'Građevinske dozvole', 'Matični uredi'],
    komentar: 'Urbanističke saglasnosti i matični uredi'
  },

  // ========== BRČKO DISTRIKT ==========
  {
    id: 'brcko-distrikt',
    name: 'Brčko Distrikt BiH',
    entity: 'BD',
    urls: [
      {
        main: 'https://bdcentral.net/obrasci/',
        description: 'Obrasci – zahtjevi za uvjerenja, urbanistička saglasnost, lokacijska informacija, prijava boravka'
      },
      {
        main: 'https://bdcentral.net/javni-registar/',
        description: 'Obrasci – izvod iz matičnih knjiga, prijava prebivališta i boravišta, prijava rođenja'
      },
      {
        main: 'https://bdcentral.net/zdravstvo/',
        description: 'Obrasci – zdravstveno osiguranje, refundacija, ortopedska pomagala'
      },
      {
        main: 'https://bdcentral.net/obrazovanje/',
        description: 'Obrasci – stipendije, upis djece u školu, nostrifikacija'
      },
      {
        main: 'https://bdcentral.net/prostorno-planiranje/',
        description: 'Obrasci – lokacijska informacija, urbanistička saglasnost, građevinske dozvole'
      }
    ],
    categories: ['Urbanizam', 'Matični uredi', 'Zdravstvo', 'Obrazovanje', 'Građevinske dozvole'],
    komentar: 'Jedinstveni entitet - objedinjuje funkcije općine, grada i kantona'
  },
];

// Search function
export function searchMunicipalities(query: string): MunicipalityData[] {
  if (!query || query.trim().length === 0) {
    return [];
  }

  const searchTerm = query.toLowerCase().trim();
  
  return municipalitiesDatabase.filter(mun => {
    const nameMatch = mun.name.toLowerCase().includes(searchTerm);
    const cantonMatch = mun.canton?.toLowerCase().includes(searchTerm);
    const regionMatch = mun.region?.toLowerCase().includes(searchTerm);
    const categoryMatch = mun.categories.some(cat => cat.toLowerCase().includes(searchTerm));
    
    return nameMatch || cantonMatch || regionMatch || categoryMatch;
  });
}

// Get municipality by ID
export function getMunicipalityById(id: string): MunicipalityData | undefined {
  return municipalitiesDatabase.find(mun => mun.id === id);
}

// Get all cantons
export function getAllCantons(): string[] {
  const cantons = new Set<string>();
  municipalitiesDatabase.forEach(mun => {
    if (mun.canton) cantons.add(mun.canton);
  });
  return Array.from(cantons).sort();
}

// Get all regions (RS)
export function getAllRegions(): string[] {
  const regions = new Set<string>();
  municipalitiesDatabase.forEach(mun => {
    if (mun.region) regions.add(mun.region);
  });
  return Array.from(regions).sort();
}

// Get municipalities by entity
export function getMunicipalitiesByEntity(entity: 'FBiH' | 'RS' | 'BD'): MunicipalityData[] {
  return municipalitiesDatabase.filter(mun => mun.entity === entity);
}