import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Search, LogIn, UserPlus, Shield, Clock, Globe, FileText, Gift, LogOut } from 'lucide-react';
import { getUserAccount, getTrialStatus, isTrialExpired, logoutUser, hasAccess } from '@/lib/trial';
import SponsorCarousel from '@/components/SponsorCarousel';
import LanguageSelector from '@/components/LanguageSelector';

const Index = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [userAccount, setUserAccount] = useState(getUserAccount());
  const [trialStatus, setTrialStatus] = useState(getTrialStatus());

  useEffect(() => {
    setUserAccount(getUserAccount());
    setTrialStatus(getTrialStatus());
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if user has access
    if (!hasAccess()) {
      if (isTrialExpired()) {
        alert('Vaš probni period je istekao. Molimo pretplatite se za nastavak korištenja.');
        navigate('/subscription');
        return;
      }
      alert('Molimo prijavite se ili registrujte za pristup.');
      navigate('/register');
      return;
    }
    
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleLogout = () => {
    logoutUser();
    setUserAccount(null);
    setTrialStatus(null);
    alert('Uspješno ste se odjavili.');
  };

  const features = [
    {
      icon: <Search className="h-8 w-8 text-[#003D7A]" />,
      title: 'Brza pretraga',
      description: 'Pronađite sve obrasce i dokumente u nekoliko sekundi',
    },
    {
      icon: <Globe className="h-8 w-8 text-[#00A651]" />,
      title: 'Višejezična podrška',
      description: 'Prevod na 5 jezika: Latinica, Ćirilica, English, Deutsch, Türkçe',
    },
    {
      icon: <FileText className="h-8 w-8 text-[#003D7A]" />,
      title: 'Sve na jednom mjestu',
      description: 'Pristup svim općinama, gradovima i kantonima BiH',
    },
    {
      icon: <Clock className="h-8 w-8 text-[#00A651]" />,
      title: 'Uštedjeno vrijeme',
      description: 'Bez potrebe za traženjem po različitim web stranicama',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Language Selector - Fixed position */}
      <div className="fixed top-4 right-4 z-50">
        <LanguageSelector />
      </div>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#003D7A] to-[#00A651] text-white py-20">
        <div className="container px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold mb-6">{t('welcome')}</h1>
            <p className="text-xl mb-8 text-gray-100">{t('welcomeDescription')}</p>
            
            {/* User Status */}
            {userAccount ? (
              <div className="mb-6 space-y-3">
                <Badge className="bg-white text-[#003D7A] hover:bg-gray-100 text-lg px-6 py-2">
                  {userAccount.status === 'trial' && (
                    <>
                      <Gift className="h-4 w-4 mr-2" />
                      Probni period: {trialStatus?.daysRemaining || 0} dana preostalo
                    </>
                  )}
                  {userAccount.status === 'paid' && (
                    <>
                      ✓ Plaćeni korisnik
                    </>
                  )}
                </Badge>
                <div className="text-sm text-gray-100">
                  Prijavljeni kao: <strong>{userAccount.name}</strong> ({userAccount.email})
                </div>
              </div>
            ) : (
              <Badge className="mb-6 bg-white text-[#003D7A] hover:bg-gray-100 text-lg px-6 py-2">
                <Gift className="h-4 w-4 mr-2" />
                Registrujte se i dobijte 10 dana besplatno!
              </Badge>
            )}

            {/* Trial Expiration Warning */}
            {userAccount && userAccount.status === 'trial' && trialStatus && trialStatus.daysRemaining <= 3 && (
              <Alert className="mb-6 bg-yellow-50 border-yellow-200 text-yellow-900">
                <AlertDescription>
                  <strong>⚠️ Upozorenje:</strong> Vaš probni period ističe za {trialStatus.daysRemaining} dana. 
                  {' '}<a href="/subscription" className="underline font-semibold">Pretplatite se sada</a> da nastavite koristiti aplikaciju.
                </AlertDescription>
              </Alert>
            )}

            {/* Authentication Buttons */}
            {!userAccount ? (
              <div className="flex flex-wrap gap-4 justify-center mb-8">
                <Button
                  size="lg"
                  variant="outline"
                  className="bg-white text-[#003D7A] hover:bg-gray-100 border-2 border-white"
                  onClick={() => navigate('/login')}
                >
                  <LogIn className="h-5 w-5 mr-2" />
                  SIGN IN
                </Button>
                <Button
                  size="lg"
                  className="bg-[#00A651] hover:bg-[#008F45] text-white"
                  onClick={() => navigate('/register')}
                >
                  <UserPlus className="h-5 w-5 mr-2" />
                  REGISTER - 10 DANA BESPLATNO
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="bg-transparent text-white hover:bg-white/10 border-2 border-white"
                  onClick={() => navigate('/admin')}
                >
                  <Shield className="h-5 w-5 mr-2" />
                  ADMIN
                </Button>
              </div>
            ) : (
              <div className="flex flex-wrap gap-4 justify-center mb-8">
                {userAccount.status === 'trial' && isTrialExpired() && (
                  <Button
                    size="lg"
                    className="bg-[#00A651] hover:bg-[#008F45] text-white"
                    onClick={() => navigate('/subscription')}
                  >
                    Pretplatite se sada
                  </Button>
                )}
                <Button
                  size="lg"
                  variant="outline"
                  className="bg-white text-[#003D7A] hover:bg-gray-100 border-2 border-white"
                  onClick={handleLogout}
                >
                  <LogOut className="h-5 w-5 mr-2" />
                  Odjavi se
                </Button>
              </div>
            )}

            {/* Search Box */}
            <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
              <div className="flex gap-2">
                <Input
                  type="text"
                  placeholder={t('searchPlaceholder')}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 h-14 text-lg bg-white text-gray-900"
                />
                <Button type="submit" size="lg" className="h-14 px-8 bg-[#00A651] hover:bg-[#008F45]">
                  <Search className="h-5 w-5 mr-2" />
                  {t('search')}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#003D7A]">
            Zašto koristiti BH PapirFinder?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-center mb-4">{feature.icon}</div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#003D7A]">
            Kako funkcioniše?
          </h2>
          <div className="max-w-4xl mx-auto space-y-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Badge className="bg-[#003D7A] text-white text-lg w-10 h-10 flex items-center justify-center rounded-full">1</Badge>
                  Registrujte se besplatno
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Kreirajte nalog i dobijte 10 dana besplatnog pristupa svim funkcijama
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Badge className="bg-[#00A651] text-white text-lg w-10 h-10 flex items-center justify-center rounded-full">2</Badge>
                  Pretražujte i preuzmite dokumente
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Tokom probnog perioda imate pristup svim općinama, gradovima i dokumentima
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Badge className="bg-[#003D7A] text-white text-lg w-10 h-10 flex items-center justify-center rounded-full">3</Badge>
                  Pretplatite se za nastavak
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Nakon isteka probnog perioda, izaberite plan pretplate i nastavite koristiti aplikaciju
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Sponsors */}
      <section className="py-16 bg-gray-50">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#003D7A]">
            Naši partneri
          </h2>
          <SponsorCarousel />
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-[#003D7A] to-[#00A651] text-white">
        <div className="container px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Spremni za početak?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Registrujte se danas i dobijte 10 dana besplatnog probnog perioda - bez obaveze plaćanja
          </p>
          <div className="flex gap-4 justify-center">
            <Button
              size="lg"
              className="bg-white text-[#003D7A] hover:bg-gray-100 text-lg px-8 py-6"
              onClick={() => navigate('/register')}
            >
              <Gift className="h-5 w-5 mr-2" />
              Započni besplatni probni period
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white hover:bg-white/10 border-2 border-white text-lg px-8 py-6"
              onClick={() => navigate('/subscription')}
            >
              Pogledaj planove
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;