import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Lock, Trash2, Eye, CheckCircle } from 'lucide-react';

const Privacy = () => {
  const { t } = useLanguage();

  return (
    <div className="container max-w-4xl mx-auto px-4 py-12">
      <Card>
        <CardHeader>
          <CardTitle className="text-3xl flex items-center gap-2">
            <Shield className="h-8 w-8 text-[#003D7A]" />
            Politika privatnosti i zaštita podataka
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-6 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              Naša obaveza prema vašoj privatnosti
            </h3>
            <p className="text-gray-700">
              BH PapirFinder je kreiran sa dobrim namjerama - da pomogne građanima Bosne i Hercegovine u brzom i jednostavnom pronalaženju besplatnih obrazaca i dokumenata. Vaša privatnost je naš prioritet.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A] flex items-center gap-2">
              <Lock className="h-6 w-6" />
              1. Zaštita ličnih podataka
            </h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span><strong>Ne pohranjujemo PayPal informacije</strong> - Sva plaćanja se obrađuju direktno kroz PayPal API. Mi nikada ne vidimo niti čuvamo vaše podatke o plaćanju.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span><strong>Automatsko brisanje pretrage</strong> - Vaši upiti za pretraživanje se automatski brišu nakon 24 sata.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span><strong>Lokalno skladištenje</strong> - Podaci se čuvaju samo na vašem uređaju (localStorage), ne na našim serverima.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span><strong>Email samo za login kod</strong> - Vaša email adresa se koristi isključivo za slanje login koda nakon plaćanja.</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A] flex items-center gap-2">
              <Eye className="h-6 w-6" />
              2. Koje podatke prikupljamo
            </h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <ul className="space-y-2 text-gray-700">
                <li><strong>Email adresa:</strong> Za slanje login koda nakon pretplate</li>
                <li><strong>Upiti za pretraživanje:</strong> Privremeno (24h) za poboljšanje usluge</li>
                <li><strong>Datum instalacije:</strong> Za praćenje besplatnog probnog perioda (10 dana)</li>
                <li><strong>Datum pretplate:</strong> Za praćenje aktivnosti pretplate</li>
              </ul>
              <p className="mt-3 text-sm text-gray-600">
                <strong>Napomena:</strong> Ne prikupljamo ime, prezime, adresu, broj telefona ili bilo koje druge lične podatke.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A] flex items-center gap-2">
              <Trash2 className="h-6 w-6" />
              3. Automatsko brisanje podataka
            </h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span><strong>Upiti za pretraživanje:</strong> Automatski se brišu nakon 24 sata</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span><strong>Login kodovi:</strong> Istječu nakon perioda pretplate</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span><strong>Sesije:</strong> Automatski se brišu nakon isteka pretplate</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A]">4. Pravna usklađenost</h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-gray-700 mb-3">
                BH PapirFinder posluje u skladu sa zakonima Federacije Bosne i Hercegovine (FBiH) i Republike Srpske (RS):
              </p>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span><strong>Zakon o zaštiti ličnih podataka BiH</strong> (usklađen sa GDPR)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span><strong>Zakoni o zaštiti potrošača</strong> FBiH i RS</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span><strong>Zakon o unutrašnjem platnom sistemu</strong> FBiH</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A]">5. Vaša prava</h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span><strong>Pravo na pristup:</strong> Možete zatražiti pristup svojim podacima</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span><strong>Pravo na brisanje:</strong> Možete zatražiti brisanje svih svojih podataka</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span><strong>Pravo na ispravku:</strong> Možete ispraviti netačne podatke</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span><strong>Pravo na prigovor:</strong> Možete prigovoriti obradi vaših podataka</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A]">6. Sigurnost plaćanja</h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-gray-700 mb-3">
                Sva plaćanja se obrađuju kroz PayPal, vodeću globalnu platformu za online plaćanja:
              </p>
              <ul className="space-y-2 text-gray-700">
                <li>• PayPal koristi 256-bit SSL enkripciju</li>
                <li>• Mi nikada ne vidimo vaše podatke o kreditnoj kartici</li>
                <li>• PayPal je PCI DSS Level 1 certificiran</li>
                <li>• Sve transakcije su zaštićene PayPal-ovom zaštitom kupca</li>
              </ul>
            </div>
          </div>

          <div className="p-6 bg-green-50 rounded-lg border border-green-200">
            <h4 className="font-semibold text-green-900 mb-3">Naša misija</h4>
            <p className="text-green-800">
              BH PapirFinder je prvi bosanski digitalni alat kreiran da pomogne pojedincima i organizacijama da brzo pronađu besplatne obrasce i dokumente. Aplikacija je napravljena sa dobrim namjerama, ne da bi finansijski iskorištavala korisnike. Pretplate su simbolične i koriste se isključivo za održavanje i proširenje funkcionalnosti aplikacije.
            </p>
          </div>

          <div className="text-center pt-6 border-t">
            <p className="text-gray-600 mb-2">Za pitanja o privatnosti kontaktirajte:</p>
            <p className="text-[#003D7A] font-semibold">
              📧 info@bh-assistant.ba
            </p>
            <p className="text-gray-600 mt-2">
              🌐 <a href="https://www.bh-assistant.ba" target="_blank" rel="noopener noreferrer" className="text-[#003D7A] hover:underline">
                www.bh-assistant.ba
              </a>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Privacy;