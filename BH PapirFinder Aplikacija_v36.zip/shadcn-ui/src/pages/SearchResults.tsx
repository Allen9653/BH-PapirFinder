import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Search, ArrowLeft, ExternalLink, FileText, MapPin, Lock } from 'lucide-react';
import { searchMunicipalities } from '@/lib/municipalities-database-enhanced';
import { hasAccess, recordSearch } from '@/lib/trial';
import { getUserAccessLevel, getSubscriptionMessage } from '@/lib/access-control';

interface SearchResult {
  name: string;
  canton?: string;
  entity?: string;
  categories?: string[];
  url?: string;
}

const SearchResults = () => {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [searchQuery, setSearchQuery] = useState(query);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const accessLevel = getUserAccessLevel();

  useEffect(() => {
    performSearch(query);
  }, [query]);

  const performSearch = async (searchTerm: string) => {
    if (!searchTerm.trim()) {
      setResults([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError('');

    try {
      const searchResults = await searchMunicipalities(searchTerm);
      
      if (searchResults.length === 0) {
        setError('Nema dostupnih obrazaca za uneseni pojam.');
      } else {
        setResults(searchResults);
        
        // Record search in history only if user has access
        if (hasAccess()) {
          recordSearch(searchTerm, searchResults.length);
        }
      }
    } catch (err) {
      console.error('Search error:', err);
      setError('Došlo je do greške pri pretrazi. Molimo pokušajte ponovo.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#003D7A] to-[#00A651] text-white py-8">
        <div className="container px-4">
          <Button
            variant="ghost"
            className="text-white hover:bg-white/10 mb-4"
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Nazad na početnu
          </Button>

          <form onSubmit={handleSearch} className="max-w-2xl">
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder={t('searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 h-12 bg-white text-gray-900"
              />
              <Button type="submit" size="lg" className="h-12 bg-[#00A651] hover:bg-[#008F45]">
                <Search className="h-5 w-5" />
              </Button>
            </div>
          </form>
        </div>
      </div>

      {/* Access Level Banner */}
      {!accessLevel.isAdmin && !accessLevel.hasSubscription && (
        <div className="bg-yellow-50 border-b border-yellow-200 py-3">
          <div className="container px-4">
            <Alert className="bg-transparent border-0 p-0">
              <AlertDescription className="text-yellow-900 flex items-center justify-between">
                <span className="flex items-center">
                  <Lock className="h-4 w-4 mr-2" />
                  {getSubscriptionMessage(language)}
                </span>
                <Button
                  size="sm"
                  className="bg-[#003D7A] hover:bg-[#002A5A] text-white"
                  onClick={() => navigate('/subscription')}
                >
                  Pretplati se
                </Button>
              </AlertDescription>
            </Alert>
          </div>
        </div>
      )}

      {/* Results */}
      <div className="container px-4 py-8">
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#003D7A] mx-auto"></div>
            <p className="mt-4 text-gray-600">Pretraga u toku...</p>
          </div>
        ) : error ? (
          <Card className="text-center py-12">
            <CardContent>
              <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                {error}
              </h3>
              <p className="text-gray-600 mt-4">
                Pokušajte sa drugim pojmom pretrage ili kontaktirajte podršku.
              </p>
            </CardContent>
          </Card>
        ) : results.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                Nema rezultata
              </h3>
              <p className="text-gray-600">
                Pokušajte sa drugim pojmom pretrage
              </p>
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-[#003D7A]">
                Rezultati pretrage za "{query}"
              </h2>
              <p className="text-gray-600 mt-2">
                Pronađeno {results.length} rezultata
              </p>
            </div>

            <div className="grid gap-4">
              {results.map((result, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-xl text-[#003D7A] mb-2">
                          <MapPin className="h-5 w-5 inline mr-2" />
                          {result.name}
                        </CardTitle>
                        <CardDescription>
                          {result.canton && (
                            <Badge variant="outline" className="mr-2">
                              {result.canton}
                            </Badge>
                          )}
                          {result.entity && (
                            <Badge variant="outline">
                              {result.entity}
                            </Badge>
                          )}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {/* Always show form names/categories */}
                    {result.categories && result.categories.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-semibold text-gray-700">Dostupni obrasci:</h4>
                        <div className="flex flex-wrap gap-2">
                          {result.categories.map((category: string, idx: number) => (
                            <Badge key={idx} className="bg-[#00A651] text-white">
                              {category}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Show URL only for subscribed users or admin */}
                    <div className="mt-4">
                      {accessLevel.canViewFormUrls && result.url ? (
                        <Button
                          className="bg-[#003D7A] hover:bg-[#002A5A]"
                          onClick={() => window.open(result.url, '_blank')}
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Posjeti web stranicu
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          className="border-[#003D7A] text-[#003D7A]"
                          onClick={() => navigate('/subscription')}
                        >
                          <Lock className="h-4 w-4 mr-2" />
                          Pretplatite se za pristup URL-u
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default SearchResults;