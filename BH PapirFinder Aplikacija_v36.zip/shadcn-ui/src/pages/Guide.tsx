import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, FileText, Download, Globe, Languages, Share2, HelpCircle } from 'lucide-react';

const Guide = () => {
  const { t } = useLanguage();

  const steps = [
    {
      icon: <Search className="h-12 w-12 text-[#003D7A]" />,
      title: t('guideStep1'),
      description: t('guideStep1'),
    },
    {
      icon: <Globe className="h-12 w-12 text-[#003D7A]" />,
      title: t('guideStep2'),
      description: t('guideStep2'),
    },
    {
      icon: <FileText className="h-12 w-12 text-[#003D7A]" />,
      title: t('guideStep3'),
      description: t('guideStep3'),
    },
    {
      icon: <Download className="h-12 w-12 text-[#003D7A]" />,
      title: t('guideStep4'),
      description: t('guideStep4'),
    },
    {
      icon: <Languages className="h-12 w-12 text-[#003D7A]" />,
      title: t('guideStep5'),
      description: t('guideStep5'),
    },
    {
      icon: <Share2 className="h-12 w-12 text-[#003D7A]" />,
      title: t('guideStep6'),
      description: t('guideStep6'),
    },
  ];

  const faqs = [
    {
      question: 'Šta je BH PapirFinder?',
      answer: 'BH PapirFinder je digitalna aplikacija kreirana od strane www.bh-assistant.ba, koja korisnicima pomaže da brže i jeftinije pronađu besplatne obrasce i formulare na više jezika.',
    },
    {
      question: 'Zašto je aplikacija multijezična?',
      answer: 'Multijezičnost je dodata kako bi pomogla strancima, dijaspori i svima koji žele koristiti obrasce na jeziku koji im je najbliži.',
    },
    {
      question: 'Da li je aplikacija besplatna?',
      answer: 'Aplikacija nudi besplatan probni period. Nakon toga se naplaćuje simbolično radi kreiranja budžeta za održavanje i proširenje funkcionalnosti.',
    },
    {
      question: 'Koje obrasce mogu pronaći?',
      answer: 'Možete pronaći osnovne besplatne obrasce i formulare koje nude općine, gradovi, kantoni/županije i Distrikt Brčko. Državni nivo nije uključen.',
    },
    {
      question: 'Koja je misija BH PapirFinder-a?',
      answer: 'Naša misija je kreiranje alata koji pomaže u prevazilaženju administrativnih prepreka između korisnika i složene birokratske strukture u BiH.',
    },
  ];

  return (
    <div className="container max-w-4xl mx-auto px-4 py-12">
      {/* FAQ Section */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-3xl flex items-center gap-2">
            <HelpCircle className="h-8 w-8 text-[#003D7A]" />
            QA – Najčešća pitanja i odgovori
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-lg mb-2 text-[#003D7A]">
                  {index + 1}. {faq.question}
                </h3>
                <p className="text-gray-700">{faq.answer}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* User Guide */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-3xl">📖 {t('guideTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="p-6 bg-blue-50 rounded-lg border border-blue-200">
              <h3 className="font-semibold text-lg mb-3">Misija i vizija</h3>
              <p className="text-gray-700">{t('guideMission')}</p>
            </div>

            <div>
              <h3 className="font-semibold text-xl mb-4">{t('guideHowTo')}</h3>
              <div className="space-y-4">
                {steps.map((step, index) => (
                  <Card key={index}>
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0">{step.icon}</div>
                        <div>
                          <h4 className="text-lg font-semibold mb-2">Korak {index + 1}</h4>
                          <p className="text-gray-600">{step.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="p-6 bg-gray-50 rounded-lg">
              <h4 className="font-semibold text-lg mb-3">Detaljno uputstvo:</h4>
              <ol className="space-y-3 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#003D7A]">1.</span>
                  <span>Na početnoj stranici unesite naziv općine/opštine, grada, kantona/županije ili Distrikta Brčko.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#003D7A]">2.</span>
                  <span>Aplikacija će vam prikazati preview aktivnog URL-a zvanične web stranice.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#003D7A]">3.</span>
                  <span>Na vašem profilu prikazat će se svi aktivni URL-ovi sa kratkim opisom (do 30 riječi).</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#003D7A]">4.</span>
                  <span>Ako ste prijavljeni i platili korištenje, dobit ćete login kod na e-mail.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-[#003D7A]">5.</span>
                  <span>Nakon prijave, otvara se vaš korisnički tab sa pregledom aktivnih stranica, formulara i mogućnostima: prevod, preuzimanje, dijeljenje, štampanje.</span>
                </li>
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ZDK Free Access */}
      <Card className="bg-green-50 border-green-200 mb-8">
        <CardHeader>
          <CardTitle>Besplatan pristup za ZDK</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 mb-4">
            Korisnici iz Zeničko-dobojskog kantona imaju besplatan pristup svim funkcijama aplikacije za sljedeće općine i gradove:
          </p>
          <ul className="grid grid-cols-2 gap-2 text-sm text-gray-700">
            <li>• Zenica</li>
            <li>• Kakanj</li>
            <li>• Visoko</li>
            <li>• Breza</li>
            <li>• Vareš</li>
            <li>• Maglaj</li>
            <li>• Tešanj</li>
            <li>• Usora</li>
            <li>• Doboj Jug</li>
            <li>• Olovo</li>
          </ul>
        </CardContent>
      </Card>

      {/* Additional Features */}
      <Card>
        <CardHeader>
          <CardTitle>Dodatne funkcije</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 mb-4">{t('guideFeatures')}</p>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-[#003D7A] font-bold">•</span>
              <span>Prevođenje dokumenata na turski, engleski, njemački jezik</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#003D7A] font-bold">•</span>
              <span>Konverzija između latinice i ćirilice</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#003D7A] font-bold">•</span>
              <span>Dijeljenje URL-ova sa prijateljima i porodicom</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-[#003D7A] font-bold">•</span>
              <span>Preuzimanje, uređivanje i štampanje dokumenata</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};

export default Guide;