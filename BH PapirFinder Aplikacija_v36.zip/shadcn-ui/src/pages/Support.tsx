import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Mail } from 'lucide-react';

const Support = () => {
  const { t } = useLanguage();

  return (
    <div className="container max-w-4xl mx-auto px-4 py-12">
      <Card>
        <CardHeader>
          <CardTitle className="text-3xl flex items-center gap-2">
            <Mail className="h-8 w-8 text-[#003D7A]" />
            {t('support')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-6 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-lg text-gray-800">{t('supportMessage')}</p>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-semibold">{t('about')}</h3>
            <p className="text-gray-700">
              BH PapirFinder je kreiran od strane B&H Assistant d.o.o. sa sjedištem u Zenici, Bosna i Hercegovina.
            </p>
            <p className="text-gray-700">
              Naša misija je olakšati pristup službenim dokumentima i obrascima za sve građane Bosne i Hercegovine kroz moderan, višejezični digitalni alat.
            </p>
          </div>

          <div className="p-6 bg-gray-50 rounded-lg">
            <h4 className="font-semibold mb-3">Kontakt informacije:</h4>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-[#003D7A]" />
                <a href="mailto:info@bh-assistant.ba" className="text-[#003D7A] hover:underline">
                  info@bh-assistant.ba
                </a>
              </li>
              <li>📍 Zenica 72 000, BiH</li>
              <li>🌐 <a href="https://www.bh-assistant.ba" target="_blank" rel="noopener noreferrer" className="text-[#003D7A] hover:underline">
                www.bh-assistant.ba
              </a></li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Support;