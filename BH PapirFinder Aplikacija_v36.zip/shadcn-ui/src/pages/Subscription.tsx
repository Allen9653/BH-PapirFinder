import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Check, CreditCard } from 'lucide-react';
import { getUserAccount } from '@/lib/trial';

const Subscription = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const userAccount = getUserAccount();

  const plans = [
    {
      id: 'monthly',
      name: 'Mjesečna pretplata',
      price: '9.99',
      currency: 'EUR',
      period: 'mjesec',
      features: [
        'Neograničene pretrage',
        'Pristup svim općinama',
        'Prevod na 5 jezika',
        'Podrška 24/7',
        'Redovni update-i',
      ],
      popular: false,
    },
    {
      id: 'yearly',
      name: 'Godišnja pretplata',
      price: '99.99',
      currency: 'EUR',
      period: 'godina',
      savings: 'Uštedite 17%',
      features: [
        'Sve iz mjesečne pretplate',
        'Prioritetna podrška',
        'Rani pristup novim funkcijama',
        'Besplatni update-i',
        '2 mjeseca gratis',
      ],
      popular: true,
    },
  ];

  const handleSubscribe = (planId: string) => {
    setSelectedPlan(planId);
    // In production, integrate with PayPal or Stripe
    alert(`Pretplata na plan: ${planId}. Integracija sa PayPal-om u razvoju.`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 py-12 px-4">
      <div className="container max-w-6xl mx-auto">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Nazad na početnu
          </Button>
        </div>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-[#003D7A] mb-4">
            Izaberite vaš plan
          </h1>
          <p className="text-xl text-gray-600">
            Jednostavne cijene, bez skrivenih troškova
          </p>
          {userAccount && userAccount.status === 'trial' && (
            <Badge className="mt-4 bg-[#00A651] text-white text-lg px-6 py-2">
              Probni period aktivan - Nadogradite za nastavak nakon isteka
            </Badge>
          )}
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {plans.map((plan) => (
            <Card
              key={plan.id}
              className={`relative ${
                plan.popular
                  ? 'border-[#00A651] border-2 shadow-lg'
                  : 'border-gray-200'
              }`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-[#00A651] text-white">
                  Najpopularnije
                </Badge>
              )}
              <CardHeader>
                <CardTitle className="text-2xl text-[#003D7A]">
                  {plan.name}
                </CardTitle>
                <CardDescription>
                  {plan.savings && (
                    <span className="text-[#00A651] font-semibold">
                      {plan.savings}
                    </span>
                  )}
                </CardDescription>
                <div className="mt-4">
                  <span className="text-5xl font-bold text-[#003D7A]">
                    {plan.price}
                  </span>
                  <span className="text-xl text-gray-600 ml-2">
                    {plan.currency}/{plan.period}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-[#00A651] flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  className={`w-full ${
                    plan.popular
                      ? 'bg-[#00A651] hover:bg-[#008F45]'
                      : 'bg-[#003D7A] hover:bg-[#002A5A]'
                  }`}
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={selectedPlan === plan.id}
                >
                  <CreditCard className="h-5 w-5 mr-2" />
                  {selectedPlan === plan.id ? 'Obrađuje se...' : 'Pretplati se'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center text-gray-600">
          <p className="mb-2">
            Sva plaćanja su sigurna i enkriptovana
          </p>
          <p className="text-sm">
            Možete otkazati pretplatu bilo kada. Nema skrivenih troškova.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Subscription;