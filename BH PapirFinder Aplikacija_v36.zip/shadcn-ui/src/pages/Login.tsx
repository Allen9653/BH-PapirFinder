import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { LogIn, ArrowLeft } from 'lucide-react';
import { loginUser } from '@/lib/trial';

const Login = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [loginCode, setLoginCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const success = loginUser(email, loginCode);
      
      if (success) {
        navigate('/');
      } else {
        setError('Neispravan email ili kod za prijavu. Molimo provjerite vaše podatke.');
      }
    } catch (err) {
      setError('Došlo je do greške pri prijavi. Molimo pokušajte ponovo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center gap-2 mb-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Nazad
            </Button>
          </div>
          <CardTitle className="text-2xl text-[#003D7A]">
            <LogIn className="h-6 w-6 inline mr-2" />
            Prijava
          </CardTitle>
          <CardDescription>
            Prijavite se sa vašim email-om i kodom za prijavu
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="email">Email adresa</Label>
              <Input
                id="email"
                type="email"
                placeholder="vas@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="loginCode">Kod za prijavu</Label>
              <Input
                id="loginCode"
                type="text"
                placeholder="Unesite vaš kod"
                value={loginCode}
                onChange={(e) => setLoginCode(e.target.value)}
                required
              />
              <p className="text-sm text-gray-500">
                Kod ste dobili nakon registracije ili plaćanja
              </p>
            </div>

            <Button
              type="submit"
              className="w-full bg-[#003D7A] hover:bg-[#002A5A]"
              disabled={loading}
            >
              {loading ? 'Prijava u toku...' : 'Prijavi se'}
            </Button>

            <div className="text-center text-sm text-gray-600">
              Nemate nalog?{' '}
              <button
                type="button"
                onClick={() => navigate('/register')}
                className="text-[#003D7A] font-semibold hover:underline"
              >
                Registrujte se
              </button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;