import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Shield, AlertCircle } from 'lucide-react';

const Terms = () => {
  const { t } = useLanguage();

  return (
    <div className="container max-w-4xl mx-auto px-4 py-12">
      <Card>
        <CardHeader>
          <CardTitle className="text-3xl flex items-center gap-2">
            <FileText className="h-8 w-8 text-[#003D7A]" />
            📜 {t('termsOfUse')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-6 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
              <Shield className="h-5 w-5 text-[#003D7A]" />
              Opšte odredbe
            </h3>
            <div className="space-y-3 text-gray-700">
              <p>
                <strong>BH PapirFinder</strong> je privatni projekat kompanije <strong>B&H Assistant d.o.o.</strong> sa sjedištem u Zenici, Bosna i Hercegovina.
              </p>
              <p>
                Sva prava korištenja, distribucije i izmjene aplikacije su zadržana od strane B&H Assistant d.o.o.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A]">1. Privatnost i zaštita podataka</h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Aplikacija <strong>ne pohranjuje lične podatke korisnika</strong>.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Svi podaci se čuvaju lokalno na vašem uređaju (localStorage).</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Ne dijelimo vaše podatke sa trećim stranama.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Login kodovi se šalju isključivo na email adresu koju ste naveli prilikom registracije.</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A]">2. Korištenje i naplata</h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Korištenje aplikacije podrazumijeva prihvatanje simbolične naplate za održavanje i razvoj.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Aplikacija nudi besplatan probni period za testiranje funkcionalnosti.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Korisnici iz Zeničko-dobojskog kantona (ZDK) imaju besplatan pristup.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Za ostale regije dostupne su sljedeće pretplate:</span>
                </li>
              </ul>
              <div className="mt-3 ml-6 space-y-1 text-gray-700">
                <p>- 10 BAM za 5 dana</p>
                <p>- 50 BAM za 30 dana</p>
                <p>- 60 BAM za 12 mjeseci</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A]">3. Autorska prava i zabrane</h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span><strong>Zabranjeno je</strong> neovlašteno kopiranje, distribucija ili izmjena aplikacije i sadržaja.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Svi logotipi, dizajn elementi i sadržaj su vlasništvo B&H Assistant d.o.o.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Neovlaštena upotreba može rezultirati pravnim sankcijama.</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A]">4. Odgovornost</h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>BH PapirFinder pruža informacije o dostupnosti obrazaca na službenim web stranicama.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Ne garantujemo tačnost ili potpunost informacija na vanjskim web stranicama.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>Korisnici su odgovorni za provjeru validnosti dokumenata na službenim stranicama.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#003D7A] font-bold">•</span>
                  <span>B&H Assistant d.o.o. ne snosi odgovornost za štetu nastalu korištenjem aplikacije.</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-xl text-[#003D7A]">5. Izmjene uslova korištenja</h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-gray-700">
                B&H Assistant d.o.o. zadržava pravo izmjene ovih uslova korištenja u bilo koje vrijeme. Korisnici će biti obaviješteni o značajnim izmjenama putem aplikacije ili email-a.
              </p>
            </div>
          </div>

          <div className="p-6 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-6 w-6 text-yellow-600 flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold text-yellow-900 mb-2">Važna napomena</h4>
                <p className="text-yellow-800">
                  Korištenjem BH PapirFinder aplikacije prihvatate sve gore navedene uslove korištenja. Ako se ne slažete sa bilo kojim dijelom ovih uslova, molimo vas da prestanete koristiti aplikaciju.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center pt-6 border-t">
            <p className="text-gray-600 mb-2">Za dodatna pitanja ili pojašnjenja kontaktirajte:</p>
            <p className="text-[#003D7A] font-semibold">
              📧 info@bh-assistant.ba
            </p>
            <p className="text-gray-600 mt-2">
              🌐 <a href="https://www.bh-assistant.ba" target="_blank" rel="noopener noreferrer" className="text-[#003D7A] hover:underline">
                www.bh-assistant.ba
              </a>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Terms;