import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { UserPlus, ArrowLeft, Gift } from 'lucide-react';
import { registerUser } from '@/lib/trial';

const Register = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (!name.trim() || !email.trim()) {
        setError('Molimo popunite sva polja.');
        setLoading(false);
        return;
      }

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        setError('Molimo unesite validnu email adresu.');
        setLoading(false);
        return;
      }

      const result = registerUser(name, email);
      
      if (result.success) {
        setSuccess(true);
        setTimeout(() => {
          navigate('/');
        }, 3000);
      } else {
        setError(result.message || 'Došlo je do greške pri registraciji.');
      }
    } catch (err) {
      setError('Došlo je do greške. Molimo pokušajte ponovo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center gap-2 mb-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Nazad
            </Button>
          </div>
          <CardTitle className="text-2xl text-[#003D7A]">
            <UserPlus className="h-6 w-6 inline mr-2" />
            Registracija
          </CardTitle>
          <CardDescription>
            Kreirajte besplatan nalog i dobijte 10 dana probnog perioda
          </CardDescription>
        </CardHeader>
        <CardContent>
          {success ? (
            <Alert className="bg-green-50 border-green-200">
              <AlertDescription className="text-green-900">
                <Gift className="h-4 w-4 inline mr-2" />
                <strong>Uspješno!</strong> Vaš nalog je kreiran. Dobili ste 10 dana besplatnog pristupa. 
                Preusmjeravanje na početnu stranicu...
              </AlertDescription>
            </Alert>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Alert className="bg-blue-50 border-blue-200">
                <AlertDescription className="text-blue-900">
                  <Gift className="h-4 w-4 inline mr-2" />
                  <strong>Besplatni probni period:</strong> 10 dana potpunog pristupa bez obaveze plaćanja
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Label htmlFor="name">Ime i prezime</Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Vaše ime i prezime"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email adresa</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="vas@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
                <p className="text-sm text-gray-500">
                  Koristićemo ovu adresu za slanje vašeg koda za prijavu
                </p>
              </div>

              <Button
                type="submit"
                className="w-full bg-[#00A651] hover:bg-[#008F45]"
                disabled={loading}
              >
                {loading ? 'Registracija u toku...' : 'Registruj se - Besplatno'}
              </Button>

              <div className="text-center text-sm text-gray-600">
                Već imate nalog?{' '}
                <button
                  type="button"
                  onClick={() => navigate('/login')}
                  className="text-[#003D7A] font-semibold hover:underline"
                >
                  Prijavite se
                </button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Register;