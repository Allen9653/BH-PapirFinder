// Region-based access control
export type Region = 'ZDK' | 'OTHER';

export interface Municipality {
  id: string;
  name: string;
  nameEn: string;
  region: Region;
  type: 'municipality' | 'town' | 'city' | 'canton' | 'district';
  officialUrl?: string;
  description: string;
  descriptionEn: string;
  active: boolean;
}

// ZDK (Zenica-Doboj Canton) municipalities - FREE ACCESS
export const zdkMunicipalities: Municipality[] = [
  {
    id: 'zenica',
    name: 'Zenica',
    nameEn: 'Zenica',
    region: 'ZDK',
    type: 'city',
    officialUrl: 'https://www.zenica.ba',
    description: 'Grad Zenica - Službena web stranica',
    descriptionEn: 'City of Zenica - Official website',
    active: true,
  },
  {
    id: 'kakanj',
    name: 'Kakanj',
    nameEn: 'Kakanj',
    region: 'ZDK',
    type: 'municipality',
    officialUrl: 'https://www.kakanj.ba',
    description: 'Općina Kakanj - Službena web stranica',
    descriptionEn: 'Municipality of Kakanj - Official website',
    active: true,
  },
  {
    id: 'visoko',
    name: 'Visoko',
    nameEn: 'Visoko',
    region: 'ZDK',
    type: 'municipality',
    officialUrl: 'https://www.visoko.ba',
    description: 'Općina Visoko - Službena web stranica',
    descriptionEn: 'Municipality of Visoko - Official website',
    active: true,
  },
  {
    id: 'breza',
    name: 'Breza',
    nameEn: 'Breza',
    region: 'ZDK',
    type: 'municipality',
    officialUrl: 'https://www.breza.ba',
    description: 'Općina Breza - Službena web stranica',
    descriptionEn: 'Municipality of Breza - Official website',
    active: true,
  },
  {
    id: 'vares',
    name: 'Vareš',
    nameEn: 'Vares',
    region: 'ZDK',
    type: 'municipality',
    officialUrl: 'https://www.vares.ba',
    description: 'Općina Vareš - Službena web stranica',
    descriptionEn: 'Municipality of Vares - Official website',
    active: true,
  },
  {
    id: 'maglaj',
    name: 'Maglaj',
    nameEn: 'Maglaj',
    region: 'ZDK',
    type: 'municipality',
    officialUrl: 'https://www.maglaj.ba',
    description: 'Općina Maglaj - Službena web stranica',
    descriptionEn: 'Municipality of Maglaj - Official website',
    active: true,
  },
  {
    id: 'tešanj',
    name: 'Tešanj',
    nameEn: 'Tesanj',
    region: 'ZDK',
    type: 'municipality',
    officialUrl: 'https://www.tesanj.ba',
    description: 'Općina Tešanj - Službena web stranica',
    descriptionEn: 'Municipality of Tesanj - Official website',
    active: true,
  },
  {
    id: 'usora',
    name: 'Usora',
    nameEn: 'Usora',
    region: 'ZDK',
    type: 'municipality',
    officialUrl: 'https://www.usora.ba',
    description: 'Općina Usora - Službena web stranica',
    descriptionEn: 'Municipality of Usora - Official website',
    active: true,
  },
  {
    id: 'doboj-jug',
    name: 'Doboj Jug',
    nameEn: 'Doboj South',
    region: 'ZDK',
    type: 'municipality',
    officialUrl: 'https://www.doboj-jug.ba',
    description: 'Općina Doboj Jug - Službena web stranica',
    descriptionEn: 'Municipality of Doboj South - Official website',
    active: true,
  },
  {
    id: 'olovo',
    name: 'Olovo',
    nameEn: 'Olovo',
    region: 'ZDK',
    type: 'municipality',
    officialUrl: 'https://www.olovo.ba',
    description: 'Općina Olovo - Službena web stranica',
    descriptionEn: 'Municipality of Olovo - Official website',
    active: true,
  },
  {
    id: 'zdk-kanton',
    name: 'Zeničko-dobojski kanton',
    nameEn: 'Zenica-Doboj Canton',
    region: 'ZDK',
    type: 'canton',
    officialUrl: 'https://www.zdk.ba',
    description: 'Zeničko-dobojski kanton - Službena web stranica',
    descriptionEn: 'Zenica-Doboj Canton - Official website',
    active: true,
  },
];

// Other regions - PAID ACCESS REQUIRED
export const otherMunicipalities: Municipality[] = [
  {
    id: 'sarajevo',
    name: 'Sarajevo',
    nameEn: 'Sarajevo',
    region: 'OTHER',
    type: 'city',
    officialUrl: 'https://www.sarajevo.ba',
    description: 'Grad Sarajevo - Službena web stranica',
    descriptionEn: 'City of Sarajevo - Official website',
    active: true,
  },
  {
    id: 'tuzla',
    name: 'Tuzla',
    nameEn: 'Tuzla',
    region: 'OTHER',
    type: 'city',
    officialUrl: 'https://www.tuzla.ba',
    description: 'Grad Tuzla - Službena web stranica',
    descriptionEn: 'City of Tuzla - Official website',
    active: true,
  },
  {
    id: 'brcko',
    name: 'Brčko Distrikt',
    nameEn: 'Brcko District',
    region: 'OTHER',
    type: 'district',
    officialUrl: 'https://www.bdcentral.net',
    description: 'Brčko Distrikt BiH - Službena web stranica',
    descriptionEn: 'Brcko District BiH - Official website',
    active: true,
  },
  {
    id: 'mostar',
    name: 'Mostar',
    nameEn: 'Mostar',
    region: 'OTHER',
    type: 'city',
    officialUrl: 'https://www.mostar.ba',
    description: 'Grad Mostar - Službena web stranica',
    descriptionEn: 'City of Mostar - Official website',
    active: true,
  },
  {
    id: 'banja-luka',
    name: 'Banja Luka',
    nameEn: 'Banja Luka',
    region: 'OTHER',
    type: 'city',
    officialUrl: 'https://www.banjaluka.rs.ba',
    description: 'Grad Banja Luka - Službena web stranica',
    descriptionEn: 'City of Banja Luka - Official website',
    active: true,
  },
];

export const allMunicipalities = [...zdkMunicipalities, ...otherMunicipalities];

export function searchMunicipalities(query: string): Municipality[] {
  const lowerQuery = query.toLowerCase();
  return allMunicipalities.filter(
    (m) =>
      m.name.toLowerCase().includes(lowerQuery) ||
      m.nameEn.toLowerCase().includes(lowerQuery)
  );
}

export function isZDKRegion(municipality: Municipality): boolean {
  return municipality.region === 'ZDK';
}

export function requiresSubscription(municipality: Municipality): boolean {
  return municipality.region === 'OTHER';
}