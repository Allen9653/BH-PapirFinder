// PayPal Webhook Security Implementation
// This should be implemented on the backend (Firebase Functions or Node.js)

import crypto from 'crypto';

interface PayPalWebhookEvent {
  id: string;
  event_type: string;
  resource: Record<string, unknown>;
  create_time: string;
}

// Verify PayPal webhook signature
export function verifyPayPalWebhookSignature(
  webhookId: string,
  transmissionId: string,
  transmissionTime: string,
  certUrl: string,
  authAlgo: string,
  transmissionSig: string,
  webhookEvent: PayPalWebhookEvent,
  webhookSecret: string
): boolean {
  // This is a simplified example
  // In production, use PayPal's official SDK for webhook verification
  
  // 1. Construct the expected signature string
  const expectedSig = `${transmissionId}|${transmissionTime}|${webhookId}|${crc32(JSON.stringify(webhookEvent))}`;
  
  // 2. Verify using HMAC-SHA256
  const hmac = crypto.createHmac('sha256', webhookSecret);
  hmac.update(expectedSig);
  const computedSig = hmac.digest('base64');
  
  // 3. Compare signatures
  return computedSig === transmissionSig;
}

// Simple CRC32 implementation for webhook verification
function crc32(str: string): number {
  let crc = 0 ^ (-1);
  for (let i = 0; i < str.length; i++) {
    crc = (crc >>> 8) ^ crc32Table[(crc ^ str.charCodeAt(i)) & 0xFF];
  }
  return (crc ^ (-1)) >>> 0;
}

const crc32Table = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i;
  for (let j = 0; j < 8; j++) {
    c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
  }
  crc32Table[i] = c;
}

// Replay protection - store processed webhook IDs
const processedWebhooks = new Set<string>();

export function isWebhookProcessed(webhookId: string): boolean {
  return processedWebhooks.has(webhookId);
}

export function markWebhookAsProcessed(webhookId: string): void {
  processedWebhooks.add(webhookId);
  
  // Clean up old entries (keep last 10000)
  if (processedWebhooks.size > 10000) {
    const entries = Array.from(processedWebhooks);
    entries.slice(0, 5000).forEach(id => processedWebhooks.delete(id));
  }
}

// Validate webhook timestamp (prevent replay attacks)
export function isWebhookTimestampValid(transmissionTime: string, maxAgeMinutes: number = 5): boolean {
  const webhookTime = new Date(transmissionTime);
  const now = new Date();
  const ageMinutes = (now.getTime() - webhookTime.getTime()) / (1000 * 60);
  
  return ageMinutes <= maxAgeMinutes;
}

// Backend webhook handler example
export async function handlePayPalWebhook(
  headers: Record<string, string>,
  body: PayPalWebhookEvent,
  webhookSecret: string
): Promise<{ success: boolean; error?: string }> {
  try {
    // 1. Verify webhook signature
    const isValid = verifyPayPalWebhookSignature(
      headers['paypal-webhook-id'],
      headers['paypal-transmission-id'],
      headers['paypal-transmission-time'],
      headers['paypal-cert-url'],
      headers['paypal-auth-algo'],
      headers['paypal-transmission-sig'],
      body,
      webhookSecret
    );
    
    if (!isValid) {
      return { success: false, error: 'Invalid webhook signature' };
    }
    
    // 2. Check for replay attack
    if (isWebhookProcessed(body.id)) {
      return { success: false, error: 'Webhook already processed' };
    }
    
    // 3. Validate timestamp
    if (!isWebhookTimestampValid(headers['paypal-transmission-time'])) {
      return { success: false, error: 'Webhook timestamp too old' };
    }
    
    // 4. Mark as processed
    markWebhookAsProcessed(body.id);
    
    // 5. Process the webhook based on event type
    switch (body.event_type) {
      case 'PAYMENT.CAPTURE.COMPLETED':
        // Handle successful payment
        await processSuccessfulPayment(body.resource);
        break;
      case 'PAYMENT.CAPTURE.DENIED':
        // Handle denied payment
        await processFailedPayment(body.resource);
        break;
      default:
        console.log('Unhandled webhook event type:', body.event_type);
    }
    
    return { success: true };
  } catch (error) {
    console.error('Webhook processing error:', error);
    return { success: false, error: 'Internal server error' };
  }
}

async function processSuccessfulPayment(resource: Record<string, unknown>): Promise<void> {
  // Generate login code
  const loginCode = generateLoginCode();
  
  // Send email with login code
  // await sendLoginCodeEmail(resource.payer.email_address, loginCode);
  
  // Log the transaction
  console.log('Payment processed:', resource.id);
}

async function processFailedPayment(resource: Record<string, unknown>): Promise<void> {
  // Log the failed payment
  console.log('Payment failed:', resource.id);
}

function generateLoginCode(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}