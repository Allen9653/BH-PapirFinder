// Storage Cleanup Utility
// Fixes corrupted localStorage data

export function cleanupCorruptedStorage(): void {
  const bh_keys = [
    'bh_papirfinder_sponsors',
    'bh_papirfinder_user_session',
    'bh_papirfinder_audit_log',
    'bh_papirfinder_searches',
    'bh_papirfinder_user_account',
    'bh_papirfinder_trial_start',
    'bh_papirfinder_language',
    'bh_papirfinder_install_dismissed',
    'bh_papirfinder_admin',
    'bh_papirfinder_subscription',
  ];

  let cleanedCount = 0;
  let errorCount = 0;

  bh_keys.forEach(key => {
    try {
      const value = localStorage.getItem(key);
      if (value === null) return;

      // Try to parse as JSON
      if (key !== 'bh_papirfinder_admin' && 
          key !== 'bh_papirfinder_language' && 
          key !== 'bh_papirfinder_install_dismissed' &&
          key !== 'bh_papirfinder_trial_start' &&
          key !== 'bh_papirfinder_subscription') {
        JSON.parse(value);
      }
    } catch (error) {
      console.warn(`Removing corrupted localStorage key: ${key}`, error);
      localStorage.removeItem(key);
      cleanedCount++;
      errorCount++;
    }
  });

  // Clean municipality cache entries
  const allKeys = Object.keys(localStorage);
  allKeys.forEach(key => {
    if (key.startsWith('municipality_')) {
      try {
        const value = localStorage.getItem(key);
        if (value) JSON.parse(value);
      } catch (error) {
        console.warn(`Removing corrupted cache key: ${key}`);
        localStorage.removeItem(key);
        cleanedCount++;
      }
    }
  });

  if (cleanedCount > 0) {
    console.log(`✅ Cleaned ${cleanedCount} corrupted localStorage entries`);
  }

  return;
}

// Run cleanup on module load
if (typeof window !== 'undefined') {
  try {
    cleanupCorruptedStorage();
  } catch (error) {
    console.error('Storage cleanup failed:', error);
  }
}