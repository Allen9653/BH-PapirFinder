// Free trial management
const TRIAL_DAYS = 10;

export function initializeTrial(): void {
  const existingTrial = localStorage.getItem('bh_papirfinder_trial_start');
  if (!existingTrial) {
    const now = new Date();
    localStorage.setItem('bh_papirfinder_trial_start', now.toISOString());
  }
}

export function getTrialStartDate(): Date | null {
  const stored = localStorage.getItem('bh_papirfinder_trial_start');
  if (stored) {
    return new Date(stored);
  }
  return null;
}

export function getRemainingDays(): number {
  const trialStart = getTrialStartDate();
  if (!trialStart) {
    initializeTrial();
    return TRIAL_DAYS;
  }

  const now = new Date();
  const diffTime = now.getTime() - trialStart.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  const remaining = TRIAL_DAYS - diffDays;

  return Math.max(0, remaining);
}

export function isTrialActive(): boolean {
  return getRemainingDays() > 0;
}

export function isSubscriptionActive(): boolean {
  const subscription = localStorage.getItem('bh_papirfinder_subscription');
  if (!subscription) {
    return false;
  }

  const expiryDate = new Date(subscription);
  const now = new Date();

  return now < expiryDate;
}

export function hasAccess(): boolean {
  return isTrialActive() || isSubscriptionActive();
}

// Auto-delete search history after 24 hours
export function saveSearchQuery(query: string): void {
  const searches = getSearchHistory();
  const now = new Date();
  
  searches.push({
    query,
    timestamp: now.toISOString(),
  });
  
  try {
    localStorage.setItem('bh_papirfinder_searches', JSON.stringify(searches));
  } catch (error) {
    console.error('Failed to save search query:', error);
  }
  
  // Clean old searches
  cleanOldSearches();
}

export function getSearchHistory(): Array<{ query: string; timestamp: string }> {
  const stored = localStorage.getItem('bh_papirfinder_searches');
  if (!stored) return [];
  
  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error('Failed to parse search history from localStorage:', error);
    // Clear corrupted data
    localStorage.removeItem('bh_papirfinder_searches');
    return [];
  }
}

export function cleanOldSearches(): void {
  const searches = getSearchHistory();
  const now = new Date();
  const twentyFourHoursAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  
  const recentSearches = searches.filter((search) => {
    const searchDate = new Date(search.timestamp);
    return searchDate > twentyFourHoursAgo;
  });
  
  try {
    localStorage.setItem('bh_papirfinder_searches', JSON.stringify(recentSearches));
  } catch (error) {
    console.error('Failed to clean old searches:', error);
  }
}

// Initialize trial on first load
if (typeof window !== 'undefined') {
  initializeTrial();
  cleanOldSearches();
}