// Translation module for Bosnian → EN/DE/TR
// Uses MyMemory Translation API (free, no API key required)

export type SupportedLanguage = 'en' | 'de' | 'tr';

interface TranslationCache {
  [key: string]: {
    translation: string;
    timestamp: number;
  };
}

// Cache translations in memory (24 hours)
const translationCache: TranslationCache = {};
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

/**
 * Translates text from Bosnian to target language
 * @param text - Text to translate (in Bosnian)
 * @param targetLang - Target language code (en, de, tr)
 * @returns Translated text
 */
export async function translateText(
  text: string,
  targetLang: SupportedLanguage
): Promise<string> {
  if (!text || text.trim().length === 0) {
    return text;
  }

  // Check cache first
  const cacheKey = `${text}_${targetLang}`;
  const cached = translationCache[cacheKey];
  
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.translation;
  }

  try {
    // Use MyMemory Translation API (free, no API key required)
    const sourceLang = 'bs'; // Bosnian
    const encodedText = encodeURIComponent(text);
    const url = `https://api.mymemory.translated.net/get?q=${encodedText}&langpair=${sourceLang}|${targetLang}`;

    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`Translation API error: ${response.status}`);
    }

    const data = await response.json();
    
    if (data.responseStatus === 200 && data.responseData?.translatedText) {
      const translation = data.responseData.translatedText;
      
      // Cache the translation
      translationCache[cacheKey] = {
        translation,
        timestamp: Date.now(),
      };
      
      return translation;
    } else {
      throw new Error('Translation failed: Invalid response');
    }
  } catch (error) {
    console.error('Translation error:', error);
    // Return original text if translation fails
    return text;
  }
}

/**
 * Translates multiple texts in batch
 * @param texts - Array of texts to translate
 * @param targetLang - Target language code
 * @returns Array of translated texts
 */
export async function translateBatch(
  texts: string[],
  targetLang: SupportedLanguage
): Promise<string[]> {
  const translations = await Promise.all(
    texts.map(text => translateText(text, targetLang))
  );
  
  return translations;
}

/**
 * Gets language name from code
 * @param langCode - Language code (en, de, tr)
 * @returns Full language name
 */
export function getLanguageName(langCode: SupportedLanguage): string {
  const languageNames: Record<SupportedLanguage, string> = {
    en: 'English',
    de: 'Deutsch',
    tr: 'Türkçe',
  };
  
  return languageNames[langCode];
}

/**
 * Clears translation cache
 */
export function clearTranslationCache(): void {
  Object.keys(translationCache).forEach(key => {
    delete translationCache[key];
  });
}

/**
 * Gets cache statistics
 * @returns Object with cache size and oldest entry age
 */
export function getCacheStats(): { size: number; oldestEntryAge: number } {
  const keys = Object.keys(translationCache);
  const now = Date.now();
  
  let oldestAge = 0;
  
  keys.forEach(key => {
    const age = now - translationCache[key].timestamp;
    if (age > oldestAge) {
      oldestAge = age;
    }
  });
  
  return {
    size: keys.length,
    oldestEntryAge: Math.floor(oldestAge / 1000 / 60), // in minutes
  };
}