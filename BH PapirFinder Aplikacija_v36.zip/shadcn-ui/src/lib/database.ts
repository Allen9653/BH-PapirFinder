// Sample database structure - User should provide actual Excel data
export interface Document {
  id: string;
  name: string;
  description: string;
  url: string;
  category: string;
}

export interface Entity {
  id: string;
  name: string;
  type: 'municipality' | 'town' | 'canton' | 'district';
  region: string;
  websiteActive: boolean;
  websiteUrl?: string;
  documents: Document[];
}

// Sample data - This should be replaced with actual data from Excel files
export const sampleDatabase: Entity[] = [
  {
    id: '1',
    name: 'Sarajevo',
    type: 'canton',
    region: 'Kanton Sarajevo',
    websiteActive: true,
    websiteUrl: 'https://www.ks.gov.ba',
    documents: [
      {
        id: 'd1',
        name: 'Zahtjev za izdavanje uvjerenja',
        description: 'Obrazac za zahtjev za izdavanje različitih vrsta uvjerenja',
        url: 'https://www.ks.gov.ba/sites/default/files/zahtjev_uvjerenje.pdf',
        category: 'Uvjerenja',
      },
      {
        id: 'd2',
        name: 'Prijava boravišta',
        description: 'Formular za prijavu privremenog ili stalnog boravišta',
        url: 'https://www.ks.gov.ba/sites/default/files/prijava_boravista.pdf',
        category: 'Boravište',
      },
    ],
  },
  {
    id: '2',
    name: 'Tuzla',
    type: 'canton',
    region: 'Tuzlanski kanton',
    websiteActive: true,
    websiteUrl: 'https://www.tk.kim.ba',
    documents: [
      {
        id: 'd3',
        name: 'Zahtjev za izdavanje lične karte',
        description: 'Obrazac za podnošenje zahtjeva za izdavanje lične karte',
        url: 'https://www.tk.kim.ba/dokumenti/licna_karta.pdf',
        category: 'Lični dokumenti',
      },
    ],
  },
  {
    id: '3',
    name: 'Brčko',
    type: 'district',
    region: 'Brčko Distrikt',
    websiteActive: true,
    websiteUrl: 'https://www.bdcentral.net',
    documents: [
      {
        id: 'd4',
        name: 'Zahtjev za registraciju vozila',
        description: 'Formular za registraciju motornih vozila',
        url: 'https://www.bdcentral.net/dokumenti/registracija_vozila.pdf',
        category: 'Saobraćaj',
      },
    ],
  },
  {
    id: '4',
    name: 'Mostar',
    type: 'town',
    region: 'Hercegova čko-neretvanski kanton',
    websiteActive: false,
    documents: [],
  },
  {
    id: '5',
    name: 'Zenica',
    type: 'town',
    region: 'Zeničko-dobojski kanton',
    websiteActive: true,
    websiteUrl: 'https://www.zenica.ba',
    documents: [
      {
        id: 'd5',
        name: 'Zahtjev za građevinsku dozvolu',
        description: 'Obrazac za podnošenje zahtjeva za izdavanje građevinske dozvole',
        url: 'https://www.zenica.ba/dokumenti/gradjevinska_dozvola.pdf',
        category: 'Građevinarstvo',
      },
    ],
  },
];

export const searchEntities = (query: string): Entity[] => {
  if (!query.trim()) return [];
  
  const lowerQuery = query.toLowerCase();
  return sampleDatabase.filter(entity =>
    entity.name.toLowerCase().includes(lowerQuery) ||
    entity.region.toLowerCase().includes(lowerQuery)
  );
};

export const getEntityById = (id: string): Entity | undefined => {
  return sampleDatabase.find(entity => entity.id === id);
};