// Google Sheets Integration
// This is a frontend interface - actual implementation requires backend (Firebase Functions)

export const GOOGLE_SHEETS_CONFIG = {
  spreadsheetId: '1CVy0yh93F7IvMsH8D2OQlwSMxhwJMJTJHP_oHMxDjMw',
  spreadsheetUrl: 'https://docs.google.com/spreadsheets/d/1CVy0yh93F7IvMsH8D2OQlwSMxhwJMJTJHP_oHMxDjMw/edit?usp=sharing',
  cacheExpirationHours: 24,
};

export interface MunicipalityData {
  name: string;
  urls: string[];
  descriptions: string[];
  forms: string[];
  komentar?: string;
  category?: string;
  timestamp?: string;
}

export interface CachedResult {
  data: MunicipalityData;
  cachedAt: string;
  expiresAt: string;
}

// Frontend cache management (localStorage)
export function getCachedMunicipality(name: string): MunicipalityData | null {
  const cacheKey = `municipality_${name.toLowerCase()}`;
  const cached = localStorage.getItem(cacheKey);
  
  if (!cached) return null;
  
  try {
    const result: CachedResult = JSON.parse(cached);
    const now = new Date();
    const expiresAt = new Date(result.expiresAt);
    
    if (now > expiresAt) {
      localStorage.removeItem(cacheKey);
      return null;
    }
    
    return result.data;
  } catch (error) {
    console.error('Cache parse error:', error);
    // Clear corrupted cache entry
    localStorage.removeItem(cacheKey);
    return null;
  }
}

export function setCachedMunicipality(name: string, data: MunicipalityData): void {
  const cacheKey = `municipality_${name.toLowerCase()}`;
  const now = new Date();
  const expiresAt = new Date(now.getTime() + GOOGLE_SHEETS_CONFIG.cacheExpirationHours * 60 * 60 * 1000);
  
  const cached: CachedResult = {
    data,
    cachedAt: now.toISOString(),
    expiresAt: expiresAt.toISOString(),
  };
  
  try {
    localStorage.setItem(cacheKey, JSON.stringify(cached));
  } catch (error) {
    console.error('Failed to cache municipality data:', error);
  }
}

export function clearAllCache(): void {
  const keys = Object.keys(localStorage);
  keys.forEach(key => {
    if (key.startsWith('municipality_')) {
      localStorage.removeItem(key);
    }
  });
}

// Mock data for development (replace with actual API calls)
export async function searchMunicipality(name: string): Promise<MunicipalityData | null> {
  // Check cache first
  const cached = getCachedMunicipality(name);
  if (cached) {
    console.log('Returning cached data for:', name);
    return cached;
  }
  
  // In production, this should call your backend API
  // Example: const response = await fetch('/api/search-municipality', { method: 'POST', body: JSON.stringify({ name }) });
  
  // Mock data for demonstration
  const mockData: Record<string, MunicipalityData> = {
    olovo: {
      name: 'Olovo',
      urls: [
        'https://olovo.ba',
        'https://olovo.ba/obrasci',
      ],
      descriptions: [
        'Službena web stranica općine Olovo',
        'Obrasci i zahtjevi za građane',
      ],
      forms: [
        'Zahtjev za izdavanje uvjerenja',
        'Zahtjev za lokacijsku dozvolu',
        'Prijava boravišta',
      ],
      komentar: 'Web portal ima digitalizovane obrasce. Potrebno je prilagoditi cookies za pristup.',
      category: 'Obrasci i zahtjevi',
    },
    goražde: {
      name: 'Goražde',
      urls: [
        'https://gorazde.ba',
        'https://gorazde.ba/dokumenti',
      ],
      descriptions: [
        'Službena web stranica grada Goražde',
        'Dokumenti i obrasci',
      ],
      forms: [
        'Zahtjev za građevinsku dozvolu',
        'Izjava o prihodu',
        'Uvjerenje o nekažnjavanju',
      ],
      komentar: 'Većina obrazaca dostupna u PDF formatu. Potrebna digitalna prijava.',
      category: 'Urbanizam',
    },
    breza: {
      name: 'Breza',
      urls: [
        'https://breza.ba',
      ],
      descriptions: [
        'Službena web stranica općine Breza',
      ],
      forms: [
        'Zahtjev za matični list',
        'Zahtjev za izvod iz matične knjige',
      ],
      komentar: 'Portal nema sigurnu vezu. Obrasci dostupni na zahtjev.',
      category: 'Matične knjige',
    },
  };
  
  const result = mockData[name.toLowerCase()] || null;
  
  if (result) {
    // Cache the result
    setCachedMunicipality(name, result);
  }
  
  return result;
}

// Backend API endpoints (to be implemented in Firebase Functions)
export const API_ENDPOINTS = {
  searchMunicipality: '/api/search-municipality',
  syncGoogleSheets: '/api/sync-google-sheets',
  clearCache: '/api/clear-cache',
  getCacheStats: '/api/cache-stats',
};