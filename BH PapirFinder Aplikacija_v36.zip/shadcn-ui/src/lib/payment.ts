import { config } from './config';

export interface PaymentIntent {
  planId: 'plan5days' | 'plan30days' | 'plan12months';
  amount: number;
  currency: string;
  email: string;
}

export interface PaymentResult {
  success: boolean;
  transactionId?: string;
  error?: string;
  loginCode?: string;
}

// Frontend payment initialization
export async function initializePayment(intent: PaymentIntent): Promise<string> {
  // This would typically call your backend API to create a PayPal order
  // The backend would use the secret key to validate and process
  
  // For now, we'll return a mock order ID
  // In production, this should call your backend endpoint
  console.log('Initializing payment with publishable key:', config.publishableKey);
  console.log('Payment intent:', intent);
  
  // Example backend call (implement this in your backend):
  // const response = await fetch('/api/payment/create-order', {
  //   method: 'POST',
  //   headers: getApiHeaders(),
  //   body: JSON.stringify(intent),
  // });
  
  return 'MOCK_ORDER_ID';
}

// Frontend payment verification
export async function verifyPayment(orderId: string): Promise<PaymentResult> {
  // This would call your backend to verify the payment
  // Backend uses secret key to validate with PayPal
  
  console.log('Verifying payment:', orderId);
  
  // Example backend call (implement this in your backend):
  // const response = await fetch('/api/payment/verify', {
  //   method: 'POST',
  //   headers: getApiHeaders(),
  //   body: JSON.stringify({ orderId }),
  // });
  
  // Mock successful payment
  return {
    success: true,
    transactionId: orderId,
    loginCode: generateMockLoginCode(),
  };
}

// Generate a mock login code (in production, this should be done on backend)
function generateMockLoginCode(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

// Send login code via email (backend should handle this)
export async function sendLoginCode(email: string, loginCode: string): Promise<boolean> {
  console.log(`Sending login code ${loginCode} to ${email}`);
  
  // This should call your backend endpoint
  // Backend uses secret key to send email via your email service
  
  // Example backend call:
  // const response = await fetch('/api/auth/send-login-code', {
  //   method: 'POST',
  //   headers: getApiHeaders(),
  //   body: JSON.stringify({ email, loginCode }),
  // });
  
  return true;
}

// PayPal SDK configuration
export function getPayPalConfig() {
  return {
    'client-id': config.paypalClientId,
    currency: 'BAM',
    intent: 'capture',
    // Enable funding sources
    'enable-funding': 'venmo,paylater',
    // Disable funding sources
    'disable-funding': 'card',
  };
}