import { addAuditLogEntry } from './audit';

// Admin authentication
export interface AdminCredentials {
  email: string;
  password: string;
}

const ADMIN_EMAIL = 'alenjusufovic@yahoo.com';
const ADMIN_PASSWORD = 'UmmaIsak2013';

export function validateAdmin(email: string, password: string): boolean {
  return email === ADMIN_EMAIL && password === ADMIN_PASSWORD;
}

export function isAdminLoggedIn(): boolean {
  return localStorage.getItem('bh_papirfinder_admin') === 'true';
}

export function loginAdmin(email: string, password: string): boolean {
  if (validateAdmin(email, password)) {
    localStorage.setItem('bh_papirfinder_admin', 'true');
    addAuditLogEntry(email, 'Admin Login', 'Admin successfully logged in', 'security');
    return true;
  }
  addAuditLogEntry(email, 'Failed Login Attempt', 'Invalid credentials provided', 'security');
  return false;
}

export function logoutAdmin(): void {
  const email = ADMIN_EMAIL;
  localStorage.removeItem('bh_papirfinder_admin');
  addAuditLogEntry(email, 'Admin Logout', 'Admin logged out', 'security');
}

// Sponsor management
export interface Sponsor {
  id: string;
  imageUrl: string;
  link?: string;
  active: boolean;
}

export function getSponsors(): Sponsor[] {
  const stored = localStorage.getItem('bh_papirfinder_sponsors');
  if (!stored) return [];
  
  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error('Failed to parse sponsors from localStorage:', error);
    // Clear corrupted data
    localStorage.removeItem('bh_papirfinder_sponsors');
    return [];
  }
}

export function saveSponsors(sponsors: Sponsor[]): void {
  try {
    localStorage.setItem('bh_papirfinder_sponsors', JSON.stringify(sponsors));
  } catch (error) {
    console.error('Failed to save sponsors to localStorage:', error);
  }
}

export function addSponsor(sponsor: Sponsor): void {
  const sponsors = getSponsors();
  sponsors.push(sponsor);
  saveSponsors(sponsors);
  addAuditLogEntry(
    ADMIN_EMAIL,
    'Sponsor Added',
    `New sponsor added: ${sponsor.imageUrl}`,
    'sponsor'
  );
}

export function removeSponsor(id: string): void {
  const sponsors = getSponsors();
  const sponsor = sponsors.find(s => s.id === id);
  const filtered = sponsors.filter((s) => s.id !== id);
  saveSponsors(filtered);
  addAuditLogEntry(
    ADMIN_EMAIL,
    'Sponsor Removed',
    `Sponsor removed: ${sponsor?.imageUrl || id}`,
    'sponsor'
  );
}

export function updateSponsor(id: string, updates: Partial<Sponsor>): void {
  const sponsors = getSponsors().map((s) =>
    s.id === id ? { ...s, ...updates } : s
  );
  saveSponsors(sponsors);
  addAuditLogEntry(
    ADMIN_EMAIL,
    'Sponsor Updated',
    `Sponsor updated: ${id}`,
    'sponsor'
  );
}

// User login with code
export interface UserSession {
  loginCode: string;
  email: string;
  expiryDate: string;
  planId: string;
}

export function saveUserSession(session: UserSession): void {
  try {
    localStorage.setItem('bh_papirfinder_user_session', JSON.stringify(session));
  } catch (error) {
    console.error('Failed to save user session to localStorage:', error);
  }
}

export function getUserSession(): UserSession | null {
  const stored = localStorage.getItem('bh_papirfinder_user_session');
  if (!stored) return null;
  
  try {
    return JSON.parse(stored);
  } catch (error) {
    console.error('Failed to parse user session from localStorage:', error);
    // Clear corrupted data
    localStorage.removeItem('bh_papirfinder_user_session');
    return null;
  }
}

export function isUserLoggedIn(): boolean {
  const session = getUserSession();
  if (!session) return false;
  
  const expiryDate = new Date(session.expiryDate);
  const now = new Date();
  
  return now < expiryDate;
}

export function logoutUser(): void {
  localStorage.removeItem('bh_papirfinder_user_session');
}