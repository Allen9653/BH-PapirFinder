// Enhanced municipalities database with transliteration support
import { municipalitiesDatabase, MunicipalityData } from '@/data/municipalities-database';
import { cyrillicToLatinText, isCyrillic } from './transliteration';

/**
 * Enhanced search function with transliteration support
 * Searches municipalities by name, canton, region, or category
 * Automatically handles Cyrillic input
 */
export async function searchMunicipalities(query: string): Promise<MunicipalityData[]> {
  if (!query || query.trim().length === 0) {
    return [];
  }

  const searchTerm = query.toLowerCase().trim();
  
  // Convert Cyrillic to Latin if needed
  const latinSearchTerm = isCyrillic(searchTerm) 
    ? cyrillicToLatinText(searchTerm).toLowerCase() 
    : searchTerm;
  
  return municipalitiesDatabase.filter(mun => {
    // Search in name
    const nameMatch = mun.name.toLowerCase().includes(searchTerm) ||
                     mun.name.toLowerCase().includes(latinSearchTerm);
    
    // Search in canton
    const cantonMatch = mun.canton?.toLowerCase().includes(searchTerm) ||
                       mun.canton?.toLowerCase().includes(latinSearchTerm);
    
    // Search in region
    const regionMatch = mun.region?.toLowerCase().includes(searchTerm) ||
                       mun.region?.toLowerCase().includes(latinSearchTerm);
    
    // Search in categories
    const categoryMatch = mun.categories.some(cat => 
      cat.toLowerCase().includes(searchTerm) ||
      cat.toLowerCase().includes(latinSearchTerm)
    );
    
    // Search in comment
    const commentMatch = mun.komentar?.toLowerCase().includes(searchTerm) ||
                        mun.komentar?.toLowerCase().includes(latinSearchTerm);
    
    return nameMatch || cantonMatch || regionMatch || categoryMatch || commentMatch;
  });
}

/**
 * Get all unique cantons
 */
export function getAllCantons(): string[] {
  const cantons = new Set<string>();
  municipalitiesDatabase.forEach(mun => {
    if (mun.canton) cantons.add(mun.canton);
  });
  return Array.from(cantons).sort();
}

/**
 * Get all unique regions (RS)
 */
export function getAllRegions(): string[] {
  const regions = new Set<string>();
  municipalitiesDatabase.forEach(mun => {
    if (mun.region) regions.add(mun.region);
  });
  return Array.from(regions).sort();
}

/**
 * Get all unique categories
 */
export function getAllCategories(): string[] {
  const categories = new Set<string>();
  municipalitiesDatabase.forEach(mun => {
    mun.categories.forEach(cat => categories.add(cat));
  });
  return Array.from(categories).sort();
}

/**
 * Filter municipalities by entity
 */
export function getMunicipalitiesByEntity(entity: 'FBiH' | 'RS' | 'BD'): MunicipalityData[] {
  return municipalitiesDatabase.filter(mun => mun.entity === entity);
}

/**
 * Filter municipalities by canton
 */
export function getMunicipalitiesByCanton(canton: string): MunicipalityData[] {
  return municipalitiesDatabase.filter(mun => mun.canton === canton);
}

/**
 * Filter municipalities by region
 */
export function getMunicipalitiesByRegion(region: string): MunicipalityData[] {
  return municipalitiesDatabase.filter(mun => mun.region === region);
}

/**
 * Filter municipalities by category
 */
export function getMunicipalitiesByCategory(category: string): MunicipalityData[] {
  return municipalitiesDatabase.filter(mun => 
    mun.categories.includes(category)
  );
}

/**
 * Get municipality by ID
 */
export function getMunicipalityById(id: string): MunicipalityData | undefined {
  return municipalitiesDatabase.find(mun => mun.id === id);
}

/**
 * Get total count of municipalities
 */
export function getTotalMunicipalitiesCount(): number {
  return municipalitiesDatabase.length;
}

/**
 * Get statistics about the database
 */
export function getDatabaseStats() {
  const entities = {
    FBiH: getMunicipalitiesByEntity('FBiH').length,
    RS: getMunicipalitiesByEntity('RS').length,
    BD: getMunicipalitiesByEntity('BD').length,
  };
  
  return {
    total: getTotalMunicipalitiesCount(),
    entities,
    cantons: getAllCantons().length,
    regions: getAllRegions().length,
    categories: getAllCategories().length,
  };
}