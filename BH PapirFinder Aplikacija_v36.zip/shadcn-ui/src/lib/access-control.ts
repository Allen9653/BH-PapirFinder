// Access control logic for BiH PapirFinder
import { isAdminLoggedIn } from './auth';
import { getUserAccount, UserAccount } from './trial';

export interface AccessLevel {
  canViewFormNames: boolean;
  canViewFormUrls: boolean;
  isAdmin: boolean;
  hasSubscription: boolean;
}

/**
 * Get the current user's access level
 */
export function getUserAccessLevel(): AccessLevel {
  const isAdmin = isAdminLoggedIn();
  
  if (isAdmin) {
    return {
      canViewFormNames: true,
      canViewFormUrls: true,
      isAdmin: true,
      hasSubscription: true,
    };
  }

  const userAccount = getUserAccount();
  const hasSubscription = userAccount?.status === 'paid' || 
                         (userAccount?.status === 'trial' && !isTrialExpired(userAccount));

  return {
    canViewFormNames: true, // All users can see form names
    canViewFormUrls: hasSubscription, // Only subscribed users can see URLs
    isAdmin: false,
    hasSubscription,
  };
}

/**
 * Check if trial has expired
 */
function isTrialExpired(account: UserAccount): boolean {
  if (!account.trialExpiryDate) return true;
  const now = new Date();
  const expiryDate = new Date(account.trialExpiryDate);
  return now >= expiryDate;
}

/**
 * Check if user can access URLs
 */
export function canAccessUrls(): boolean {
  const access = getUserAccessLevel();
  return access.canViewFormUrls;
}

/**
 * Check if user is admin
 */
export function isAdmin(): boolean {
  return isAdminLoggedIn();
}

/**
 * Get subscription status message
 */
export function getSubscriptionMessage(language: string = 'bs'): string {
  const access = getUserAccessLevel();
  
  if (access.isAdmin) {
    return language === 'en' 
      ? 'Admin - Full Access' 
      : 'Admin - Pun pristup';
  }
  
  if (access.hasSubscription) {
    return language === 'en' 
      ? 'Subscribed - Full Access' 
      : 'Pretplaćen - Pun pristup';
  }
  
  return language === 'en' 
    ? 'Subscribe to access form URLs' 
    : 'Pretplatite se za pristup URL-ovima obrazaca';
}