import { useLanguage } from '@/contexts/LanguageContext';
import { Link } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';

const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="border-t bg-gray-50 mt-auto">
      <div className="container px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-semibold text-lg mb-4 text-[#003D7A]">{t('appName')}</h3>
            <p className="text-sm text-gray-600 mb-4">{t('welcomeDescription')}</p>
            <a 
              href="https://www.bh-assistant.ba" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-sm text-[#003D7A] hover:underline flex items-center gap-1"
            >
              www.bh-assistant.ba
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">{t('about')}</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/privacy" className="text-sm text-gray-600 hover:text-[#003D7A] transition-colors">
                  {t('privacyPolicy')}
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-sm text-gray-600 hover:text-[#003D7A] transition-colors">
                  {t('termsOfUse')}
                </Link>
              </li>
              <li>
                <Link to="/guide" className="text-sm text-gray-600 hover:text-[#003D7A] transition-colors">
                  {t('userGuide')}
                </Link>
              </li>
              <li>
                <Link to="/support" className="text-sm text-gray-600 hover:text-[#003D7A] transition-colors">
                  {t('support')}
                </Link>
              </li>
              <li>
                <Link to="/subscription" className="text-sm text-gray-600 hover:text-[#003D7A] transition-colors">
                  {t('subscription')}
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">{t('features')}</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• {t('feature1')}</li>
              <li>• {t('feature2')}</li>
              <li>• {t('feature3')}</li>
              <li>• {t('feature4')}</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center">
          <p className="text-xs text-gray-600 leading-relaxed">
            All rights reserved. <strong>B&H Assistant d.o.o.</strong> | Zenica 72000 | 
            JIB: 4219296620005 | MBS: 43-01-0177-25 | 
            Spajamo Kulture Stvaramo Šanse
          </p>
          <p className="text-xs text-gray-500 mt-2">
            <a 
              href="https://mgx.dev/app/7cd5641924d04376a0c3aef2a0351d57" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-[#003D7A] hover:underline inline-flex items-center gap-1"
            >
              https://mgx.dev/app/7cd5641924d04376a0c3aef2a0351d57
              <ExternalLink className="h-3 w-3" />
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;