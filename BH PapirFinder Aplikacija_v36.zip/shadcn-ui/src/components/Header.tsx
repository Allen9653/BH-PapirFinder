import { useLanguage } from '@/contexts/LanguageContext';
import { Language } from '@/lib/i18n';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, Shield, Home, LogOut, User } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { isAdminLoggedIn } from '@/lib/auth';
import { getUserAccount, logoutUser } from '@/lib/trial';

const Header = () => {
  const { language, setLanguage, t } = useLanguage();
  const navigate = useNavigate();
  const isAdmin = isAdminLoggedIn();
  const userAccount = getUserAccount();

  const languages: { value: Language; label: string }[] = [
    { value: 'bs', label: 'BHS (Latinica)' },
    { value: 'sr-Cyrl', label: 'СРП (Ћирилица)' },
    { value: 'en', label: 'English' },
    { value: 'tr', label: 'Türkçe' },
    { value: 'de', label: 'Deutsch' },
  ];

  const handleLogout = () => {
    logoutUser();
    navigate('/');
  };

  const NavLinks = () => (
    <>
      <Link to="/" className="text-sm font-medium hover:text-primary transition-colors">
        {t('home')}
      </Link>
      <Link to="/subscription" className="text-sm font-medium hover:text-primary transition-colors">
        {t('subscription')}
      </Link>
      <Link to="/terms" className="text-sm font-medium hover:text-primary transition-colors">
        {t('termsOfUse')}
      </Link>
      <Link to="/guide" className="text-sm font-medium hover:text-primary transition-colors">
        {t('userGuide')}
      </Link>
      <Link to="/support" className="text-sm font-medium hover:text-primary transition-colors">
        {t('support')}
      </Link>
      {isAdmin && (
        <Link to="/admin" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1">
          <Shield className="h-4 w-4" />
          {t('adminPanel')}
        </Link>
      )}
    </>
  );

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-4">
          {/* Homepage Return Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/')}
            className="hover:bg-[#003D7A]/10"
            title={t('home')}
          >
            <Home className="h-5 w-5 text-[#003D7A]" />
          </Button>

          <Link to="/" className="flex items-center gap-2">
            <img 
              src="https://mgx-backend-cdn.metadl.com/generate/images/446618/2026-01-06/73ed421d-9866-448f-b32c-399d52a7ab76.png" 
              alt="BH PapirFinder Logo" 
              className="h-10 w-10"
            />
            <span className="text-xl font-bold text-[#003D7A] hidden sm:inline">{t('appName')}</span>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <NavLinks />
        </nav>

        <div className="flex items-center gap-4">
          {/* User Status */}
          {userAccount && (
            <div className="hidden md:flex items-center gap-2">
              <Badge variant="outline" className="text-xs">
                <User className="h-3 w-3 mr-1" />
                {userAccount.name}
              </Badge>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-xs"
              >
                <LogOut className="h-3 w-3 mr-1" />
                Odjava
              </Button>
            </div>
          )}

          <Select value={language} onValueChange={(value) => setLanguage(value as Language)}>
            <SelectTrigger className="w-[160px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {languages.map((lang) => (
                <SelectItem key={lang.value} value={lang.value}>
                  {lang.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Mobile Menu */}
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <nav className="flex flex-col gap-4 mt-8">
                <NavLinks />
                {userAccount && (
                  <>
                    <div className="border-t pt-4">
                      <p className="text-sm text-gray-600 mb-2">
                        Prijavljeni kao: <strong>{userAccount.name}</strong>
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleLogout}
                        className="w-full"
                      >
                        <LogOut className="h-4 w-4 mr-2" />
                        Odjavi se
                      </Button>
                    </div>
                  </>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;