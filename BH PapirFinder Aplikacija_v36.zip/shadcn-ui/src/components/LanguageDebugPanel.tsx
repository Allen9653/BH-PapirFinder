import { useState, useEffect } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bug, X, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { Language } from '@/lib/i18n';

const LanguageDebugPanel = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [mountTime] = useState<number>(Date.now());
  const [renderCount, setRenderCount] = useState(0);

  // Always call the hook - it's required by React rules
  const languageContext = useLanguage();

  useEffect(() => {
    setRenderCount(prev => prev + 1);
  }, [languageContext.language]);

  // Only show in development
  if (process.env.NODE_ENV !== 'development') {
    return null;
  }

  const handleClearStorage = () => {
    localStorage.clear();
    window.location.reload();
  };

  const handleResetLanguage = () => {
    localStorage.removeItem('bh_papirfinder_language');
    languageContext.setLanguage('bs');
  };

  return (
    <>
      {/* Toggle Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 z-50 rounded-full w-12 h-12 p-0 shadow-lg"
        variant="default"
        title="Language Context Debug Panel"
      >
        <Bug className="h-5 w-5" />
      </Button>

      {/* Debug Panel */}
      {isOpen && (
        <Card className="fixed bottom-20 right-4 z-50 w-96 max-h-[80vh] overflow-auto shadow-2xl">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Bug className="h-5 w-5" />
                Language Context Debug
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="h-8 w-8 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            {/* Provider Status */}
            <div className="space-y-2">
              <h3 className="font-semibold text-xs uppercase text-gray-500">Provider Status</h3>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <Badge variant="default" className="bg-green-600">Connected</Badge>
              </div>
            </div>

            {/* Current State */}
            <div className="space-y-2">
              <h3 className="font-semibold text-xs uppercase text-gray-500">Current State</h3>
              <div className="space-y-1 p-3 bg-gray-50 rounded border">
                <div className="flex justify-between">
                  <span className="text-gray-600">Language:</span>
                  <Badge variant="outline">{languageContext.language}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Render Count:</span>
                  <Badge variant="outline">{renderCount}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Uptime:</span>
                  <span className="font-mono text-xs">
                    {Math.floor((Date.now() - mountTime) / 1000)}s
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Loading:</span>
                  <Badge variant={languageContext.isLoading ? 'default' : 'outline'}>
                    {languageContext.isLoading ? 'Yes' : 'No'}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Available Languages */}
            <div className="space-y-2">
              <h3 className="font-semibold text-xs uppercase text-gray-500">Available Languages</h3>
              <div className="flex flex-wrap gap-2">
                {(['bs', 'bs-Cyrl', 'sr-Cyrl', 'en', 'de', 'tr'] as Language[]).map(lang => (
                  <Badge
                    key={lang}
                    variant={languageContext.language === lang ? 'default' : 'outline'}
                    className="cursor-pointer"
                    onClick={() => languageContext.setLanguage(lang)}
                  >
                    {lang}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Translation Test */}
            <div className="space-y-2">
              <h3 className="font-semibold text-xs uppercase text-gray-500">Translation Test</h3>
              <div className="p-3 bg-gray-50 rounded border space-y-1 text-xs">
                <div><strong>appName:</strong> {languageContext.t('appName')}</div>
                <div><strong>search:</strong> {languageContext.t('search')}</div>
                <div><strong>welcome:</strong> {languageContext.t('welcome')}</div>
              </div>
            </div>

            {/* LocalStorage Data */}
            <div className="space-y-2">
              <h3 className="font-semibold text-xs uppercase text-gray-500">LocalStorage</h3>
              <div className="p-3 bg-gray-50 rounded border space-y-1 text-xs font-mono">
                <div className="break-all">
                  <strong>language:</strong>{' '}
                  {localStorage.getItem('bh_papirfinder_language') || 'null'}
                </div>
                <div>
                  <strong>total keys:</strong>{' '}
                  {Object.keys(localStorage).filter(k => k.startsWith('bh_papirfinder_')).length}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-2 border-t">
              <h3 className="font-semibold text-xs uppercase text-gray-500">Actions</h3>
              <div className="flex flex-col gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleResetLanguage}
                  className="w-full justify-start"
                >
                  <RefreshCw className="h-3 w-3 mr-2" />
                  Reset Language to Default
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleClearStorage}
                  className="w-full justify-start text-red-600 hover:text-red-700"
                >
                  <X className="h-3 w-3 mr-2" />
                  Clear All Storage & Reload
                </Button>
              </div>
            </div>

            {/* Info */}
            <div className="text-xs text-gray-500 pt-2 border-t">
              <p>🔧 Development only - Not visible in production</p>
              <p className="mt-1">Click the bug icon to close this panel</p>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
};

export default LanguageDebugPanel;