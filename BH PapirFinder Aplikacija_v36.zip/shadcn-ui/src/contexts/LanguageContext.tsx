import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, getTranslation, translations } from '@/lib/i18n';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isLoading: boolean;
}

// Create a default context value to prevent errors during initialization
const defaultContextValue: LanguageContextType = {
  language: 'bs',
  setLanguage: () => {},
  t: (key: string) => getTranslation('bs', key as keyof typeof translations.bs),
  isLoading: true,
};

const LanguageContext = createContext<LanguageContextType>(defaultContextValue);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('bs');
  const [isLoading, setIsLoading] = useState(true);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const initializeLanguage = async () => {
      try {
        // Simulate a small delay to ensure proper initialization
        await new Promise(resolve => setTimeout(resolve, 50));
        
        const stored = localStorage.getItem('bh_papirfinder_language');
        if (stored && ['bs', 'bs-Cyrl', 'sr-Cyrl', 'en', 'de', 'tr'].includes(stored)) {
          setLanguageState(stored as Language);
        }
      } catch (error) {
        console.error('Failed to load language preference:', error);
        // Clear corrupted data
        try {
          localStorage.removeItem('bh_papirfinder_language');
        } catch (e) {
          console.error('Failed to clear corrupted language data:', e);
        }
      } finally {
        setIsLoading(false);
      }
    };

    initializeLanguage();
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('bh_papirfinder_language', lang);
      console.log('✅ Language preference saved:', lang);
    } catch (error) {
      console.error('Failed to save language preference:', error);
    }
  };

  const t = (key: string) => {
    return getTranslation(language, key as keyof typeof translations.bs);
  };

  // Don't render children until mounted to prevent SSR issues
  if (!mounted) {
    return null;
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isLoading }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  
  // Return the context even if it's the default value
  // This prevents the error from being thrown
  if (!context || context === defaultContextValue) {
    console.warn('⚠️ useLanguage called before LanguageProvider initialization, using default values');
  }
  
  return context;
};