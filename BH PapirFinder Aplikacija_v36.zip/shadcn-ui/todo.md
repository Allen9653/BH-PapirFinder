# BH PapirFinder - Progressive Web App Development Plan

## Design Guidelines

### Design References
- **Gov.uk**: Clean, accessible government interface
- **Modern PWA Standards**: Mobile-first, touch-friendly
- **Style**: Professional Government Portal + Multilingual Support

### Color Palette
- Primary: #003D7A (Government Blue - headers, primary actions)
- Secondary: #F0F4F8 (Light Blue Gray - backgrounds)
- Accent: #00A651 (Success Green - active status)
- Warning: #DC3545 (Red - inactive status)
- Text: #1A1A1A (Dark Gray), #666666 (Secondary text)
- White: #FFFFFF (Cards, backgrounds)

### Typography
- Heading1: Inter font-weight 700 (32px)
- Heading2: Inter font-weight 600 (24px)
- Heading3: Inter font-weight 600 (18px)
- Body: Inter font-weight 400 (16px)
- Small: Inter font-weight 400 (14px)

### Key Component Styles
- **Buttons**: Primary blue (#003D7A), rounded-lg, hover: darken 10%
- **Cards**: White background, subtle shadow, 12px rounded
- **Input Fields**: Border with focus state, 8px rounded
- **Language Selector**: Dropdown in header, flag icons

### Layout & Spacing
- Mobile-first responsive design
- Touch targets minimum 44px
- Section padding: 24px vertical, 16px horizontal
- Card spacing: 16px gaps

### Images to Generate
1. **hero-bosnia-government.jpg** - Bosnia and Herzegovina government building, professional (Style: photorealistic)
2. **icon-search-documents.png** - Search icon for documents (Style: minimalist, vector-style)
3. **icon-municipality.png** - Municipality/town icon (Style: minimalist, vector-style)
4. **logo-bh-papirfinder.png** - App logo with Bosnia flag colors (Style: vector-style, professional)

---

## Development Tasks

### 1. Project Structure & Configuration
- Update package.json with PWA dependencies
- Create manifest.json for PWA
- Setup service worker for offline support
- Configure i18n system for multilingual support

### 2. Multilingual System (i18n)
- Create translation files for: BHS Latin, BHS Cyrillic, English, Turkish, German
- Implement language switcher component
- Setup language persistence in localStorage
- Create Cyrillic/Latin script converter for Serbian

### 3. Database Structure
- Create JSON database structure for:
  - Municipalities (općine)
  - Towns (gradovi)
  - Cantons (kantoni)
  - Districts (distrikti)
  - URLs and document information
- Note: User needs to provide Excel data or sample structure will be created

### 4. Payment Integration (PayPal)
- Implement trial period tracking (10 days)
- PayPal payment gateway integration (alenjusufovic@yahoo.com)
- Subscription plans: 5 days (10 BAM), 30 days (50 BAM), 12 months (60 BAM)
- Subscription validation and expiry checking
- No personal data storage (privacy-first)

### 5. Core Features
- Search input with autocomplete
- Municipality/canton/district lookup
- Active website preview display
- Document URL listing with descriptions
- Inactive website message (multilingual)
- Download, edit, translate, share, print functionality

### 6. Pages & Components
- Homepage with search
- Search results page
- Document viewer/manager
- Terms of Use (Uslovi korištenja)
- User Guide (Uputstvo za korištenje)
- Payment/subscription page

### 7. PWA Features
- Service worker for offline functionality
- App manifest for installation
- Cache strategy for documents
- Push notifications (optional)

### 8. Testing & Optimization
- Mobile responsiveness testing
- Cross-browser compatibility
- Performance optimization
- Accessibility compliance

### 9. Final Checks
- Lint and build
- PWA audit
- Payment flow testing